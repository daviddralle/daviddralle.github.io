"""Reassign preserved original and recovered bed pixels to the corrected axis."""
from pathlib import Path
import json,math,hashlib
import numpy as np,pandas as pd,fiona,rasterio
from scipy.spatial import cKDTree
from shapely.geometry import shape,LineString,Point,mapping
from shapely.ops import substring
P=Path(__file__).parent;F=P.parent;O=F/'qgis_full_mainstem'
line=shape(json.loads((P/'route_final.geojson').read_text())['features'][0]['geometry']);intervals=json.loads((P/'intervals.json').read_text());n=len(intervals)
coords=np.asarray(line.coords);a=coords[:-1];delta=np.diff(coords,axis=0);length=np.linalg.norm(delta,axis=1);cum=np.r_[0,np.cumsum(length)];tree=cKDTree(a+delta/2)
assert np.max(length)<20
width=np.array([i['channel_width_m'] for i in intervals]);limits=np.clip(width*.5+12,20,300)
def locate(xy):
 # Exact projection onto candidate segments. Dense axis vertices bound candidate lengths.
 _,idx=tree.query(xy,k=8,workers=2);v=delta[idx];t=np.clip(np.einsum('nki,nki->nk',xy[:,None,:]-a[idx],v)/np.maximum(length[idx]**2,1e-12),0,1);q=a[idx]+t[:,:,None]*v;d2=np.sum((xy[:,None,:]-q)**2,axis=2);j=np.argmin(d2,axis=1);best=idx[np.arange(len(xy)),j];chain=cum[best]+t[np.arange(len(xy)),j]*length[best];dist=np.sqrt(d2[np.arange(len(xy)),j]);return chain,dist
areas=np.zeros(n,np.int64);direct=np.zeros(n,np.int64);densitysum=np.zeros(n);densityn=np.zeros(n,np.int64);values={r:[[] for _ in range(n)] for r in [1,2,5]};zmin=np.full(n,np.inf);zmax=np.full(n,-np.inf);assigned=0;unassigned=0;total=0;checks=[]
def source(folder,name):
 p=P/'merged'/folder/name
 return p if p.exists() else F/folder/name
stats=[json.loads(source('raster_metadata',p.name).read_text()) for p in sorted((F/'raster_metadata').glob('*.json'))]
# Sparse interval-ID raster provides an inspectable spatial assignment (0 = outside selected corridor).
with rasterio.open(O/'eel_mainstem_bathy_1m.tif') as ds:profile=ds.profile;left,bottom,right,top=ds.bounds
profile.update(dtype='uint16',nodata=0,compress='deflate',predictor=2,BIGTIFF='YES',SPARSE_OK='YES')
assignment_path=O/'eel_mainstem_interval_ids_v2_1m.tif'
with rasterio.open(assignment_path,'w',**profile) as output:
 output.update_tags(route_version='lidar2014-v2',meaning='1-based 100 m interval id; 0 outside adaptive mainstem corridor or no supported bed',assignment='Exact segment projection among 8 nearest segment centers; lateral limit max(20,min(300,half observed channel width+12)) m; route flags retained separately')
 for i,s in enumerate(stats):
  if not s['valid_cells']:continue
  stem=s['tile'];x0,y0,x1,y1=s['grid']
  with rasterio.open(source('bathy_tiles',stem+'_support.tif')) as ds:support=ds.read(1)
  rr,cc=np.nonzero(support);xy=np.column_stack([x0+cc+.5,y1-rr-.5]);chain,dist=locate(xy);bins=np.minimum((chain/100).astype(int),n-1);keep=dist<=limits[bins];total+=len(xy);assigned+=int(keep.sum());unassigned+=int((~keep).sum());b=bins[keep];r=rr[keep];c=cc[keep]
  areas+=np.bincount(b,minlength=n);direct+=np.bincount(b[support[r,c]==1],minlength=n)
  ids=np.zeros(support.shape,np.uint16);ids[r,c]=b+1;output.write(ids,1,window=rasterio.windows.Window(int(x0-left),int(top-y1),1000,1000))
  with rasterio.open(source('bathy_tiles',stem+'.tif')) as ds:z=ds.read(1)[r,c]
  np.minimum.at(zmin,b,z);np.maximum.at(zmax,b,z)
  for radius in [0,1,2,5]:
   filename=source('roughness_tiles',stem+('_density.tif' if radius==0 else f'_rms_r{radius}m.tif'))
   if not filename.exists():continue
   with rasterio.open(filename) as ds:v=ds.read(1)[r,c]
   good=(v!=-9999)&np.isfinite(v);bv=b[good];v=v[good]
   if radius==0:densitysum+=np.bincount(bv,weights=v,minlength=n);densityn+=np.bincount(bv,minlength=n)
   else:
    order=np.argsort(bv);bv=bv[order];v=v[order];cuts=np.r_[0,np.flatnonzero(np.diff(bv))+1,len(bv)]
    for lo,hi in zip(cuts[:-1],cuts[1:]):
     if hi>lo:values[radius][int(bv[lo])].append(v[lo:hi])
  # Independent Shapely check spread across all tiles, including excluded pixels.
  inds=np.linspace(0,len(xy)-1,min(4,len(xy))).astype(int)
  for k in inds:
   point=Point(xy[k]);exact=line.project(point);error=abs(exact-chain[k]);checks.append(error)
   assert error<1e-5,(stem,error)
  if i%40==0:print('Reassigned',i,'/',len(stats),'tiles',flush=True)
assert assigned+unassigned==total and areas.sum()==assigned
records=[]
for j,it in enumerate(intervals):
 r={k:v for k,v in it.items() if k not in ['xy','i']};r.update(interval_id=j+1,supported_bed_area_m2=int(areas[j]),direct_sampled_cell_area_m2=int(direct[j]),bed_mean_return_density=float(densitysum[j]/densityn[j]) if densityn[j] else None,min_bed_elevation_m=float(zmin[j]) if areas[j] else None,max_bed_elevation_m=float(zmax[j]) if areas[j] else None,lateral_assignment_limit_m=float(limits[j]))
 for radius in [1,2,5]:
  v=np.concatenate(values[radius][j]) if values[radius][j] else np.array([])
  r.update({f'rough_r{radius}_ncells':len(v),f'rough_r{radius}_median_m':float(np.median(v)) if len(v) else None,f'rough_r{radius}_p90_m':float(np.quantile(v,.9)) if len(v) else None,f'rough_r{radius}_fraction_of_supported_bed':len(v)/areas[j] if areas[j] else None})
 records.append(r)
table=pd.DataFrame(records);table.to_csv(O/'roughness_predictors_100m_v2.csv',index=False)
gpkg=O/'river_centerline_v2.gpkg';schema={'geometry':'LineString','properties':{k:'str' if k=='status' else 'int' if k in ['auto_ok','interval_id','branch_count'] or k.endswith('_ncells') else 'float' for k in records[0]}}
with fiona.open(gpkg,'w',driver='GPKG',layer='roughness_corrected_100m',schema=schema,crs='EPSG:26910') as dst:
 for it,r in zip(intervals,records):dst.write({'geometry':mapping(LineString(it['xy'])),'properties':{k:int(v) if schema['properties'][k]=='int' else v for k,v in r.items()}})
old=shape(json.loads((P/'reference_route.geojson').read_text()))
with fiona.open(gpkg,'w',driver='GPKG',layer='original_NHD_guide',schema={'geometry':'LineString','properties':{'description':'str'}},crs='EPSG:26910') as dst:dst.write({'geometry':mapping(old),'properties':{'description':'Original approximate NLDI guide. Old river kilometres are not interchangeable with v2.'}})
with fiona.open(gpkg,'w',driver='GPKG',layer='cross_sections_corrected_250m',schema={'geometry':'LineString','properties':{'river_km':'float','status':'str','auto_ok':'int'}},crs='EPSG:26910') as dst:
 for s in np.arange(0,line.length,250):
  it=intervals[min(int(s/100),n-1)]
  if not it['auto_ok']:continue
  q=np.array(line.interpolate(s).coords[0]);v=np.array(line.interpolate(min(line.length,s+20)).coords[0])-np.array(line.interpolate(max(0,s-20)).coords[0]);v/=np.linalg.norm(v);normal=np.array([-v[1],v[0]]);half=max(100,it['channel_width_m']*.5+30)
  dst.write({'geometry':mapping(LineString([q-normal*half,q+normal*half])),'properties':{'river_km':s/1000,'status':it['status'],'auto_ok':1}})
summary={'route_version':'lidar2014-v2','source_bed_cells':total,'assigned_mainstem_cells':assigned,'outside_selected_corridor_cells':unassigned,'all_cells_accounted_for':True,'exact_projection_checks':len(checks),'max_chainage_error_m':max(checks),'roughness_assigned_cells':{str(r):int(table[f'rough_r{r}_ncells'].sum()) for r in [1,2,5]},'flagged_interval_values_retained_with_quality_fields':True,'note':'Original supported raster values are preserved; newly recovered class-14 bed cells were added using the original methods. Interval assignment follows the v2 route. Uncertain interval statistics remain available with flags but are omitted from the default viewer profile.'}
(P/'reassignment_qa.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2),flush=True)
