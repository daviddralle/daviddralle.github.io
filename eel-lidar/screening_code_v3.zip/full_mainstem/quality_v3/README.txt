EEL RIVER SOURCE-RETURN SCREEN V3 — EXPLORATORY

Purpose
The original class-14 candidate-bed surface includes returns coincident with
class-15 candidate surface returns. At the audited km 152.4 pool this created a
false raised plateau. Screening removes that plateau without inventing a bed
where lower returns are absent. It does not establish true bed everywhere.

The original source LAZ files, v2 products and original optical pilot are preserved.
Channel geometry and river kilometres remain route v2. This is a revision to
bed-return selection, interpolation and raw-point roughness, not a new route.

METHOD
1. Distinct XYZ class-14 points from the existing corridor and recovered bends.
   Class 15 supplies provisional water-surface elevations; the source class
   interpretations remain provisional and surface errors can remain.
2. Surface medians in 10 m river-distance bins, >=10 returns, scaled MAD <=0.20 m.
   Only interpolate between bins <=60 m apart; require a surface return within
   40 m XY and the adaptive channel distance (25–300 m). No distant extrapolation.
3. A bed return passes surface separation if it is more than max(0.35 m, 3 times
   bracketing-bin MAD) below the surface. Within that tolerance is ambiguous:
   it can be true shallow bed OR a water-surface return. It is excluded from the
   new analysis layer, not declared erroneous. Above-surface returns are excluded.
4. Retained candidates require >=5 distinct XYZ points (including themselves)
   inside an ellipsoid with XY radius 2 m and vertical radius 0.30 m. Neighborhoods
   use the same candidate selection and neighboring source-tile halos. Sparse,
   steep, or genuinely rough bed can fail this conservative support criterion.
5. Where a water-surface check is unavailable, coherent candidates remain in the
   elevation and roughness products as category 4. They are unassessed, not verified.
6. Rebuild 1 m bed with the original TIN bounds (longest edge <=3 m, nearest return
   <=1.5 m). Restrict output to original v2 supported footprint. Interpolated values
   that fail surface separation are also omitted. No broad gap filling.
7. Recompute PCA roughness from retained raw XYZ points, never from the gridded
   DEM: horizontal radius 1/2/5 m; >=5 distinct points per output cell, >=10 in its
   neighborhood; second/largest covariance eigenvalue >=0.01. No D50/D84 inference.
8. Assign supported pixels to the unchanged v2 axis using the established exact
   segment-projection and adaptive lateral bound. Export category areas for each
   100 m interval. These denominators describe ORIGINAL candidate-bed support,
   not independently delineated wetted-channel area.

RASTER CODES (eel_mainstem_bed_quality_v3_1m.tif)
0 no original supported bed (NoData)
1 retained coherent bed separated below local surface
2 excluded shallow/surface ambiguity
3 excluded above-surface candidate
4 retained coherent candidate; local surface check unavailable
5 other unresolved support (e.g. sparse/isolated returns or lost TIN support)
The quality TIFF categories describe output pixels; point_flags use the related
point-level categories described in method.json. Different lower and upper
returns can coexist in one pixel; valid lower bed takes precedence in the TIFF.

LIMITS
These thresholds are exploratory, not a calibrated bottom/surface classifier.
Shallow areas are preferentially removed, so coverage and roughness can change
for sampling reasons. Unassessed category 4 may retain false surface elevations.
Submerged vegetation, deeper multiple-return bands, sensor/strip effects, or
water-surface model errors can remain. A quality code is not field validation.
No new refraction, datum, registration, or stage correction was made.

The embedded original-comparison raster is a compact uint16 encoding rounded to
1 cm: z_m=encoded/100-1, zero is NoData. It is a display comparison only. Original
full-precision v2 data remain in qgis_full_mainstem. Cross sections use full
float32 v3 bed; original comparison does not enter statistics or contours.

REPRODUCE (lab Python with numpy, scipy, rasterio, numba, shapely, fiona, pandas)
python screen_points.py
OPENBLAS_NUM_THREADS=1 python build_products.py
python summarize.py
python assemble.py
python aggregate.py
OPENBLAS_NUM_THREADS=1 python qa.py
QT_QPA_PLATFORM=offscreen /Applications/QGIS.app/Contents/MacOS/python qgis_project.py
Then viewer/build_viewer.py and the numerical/display checks in viewer/.
Source files and point caches are referenced relative to this folder's parent.

Sources: NCALM CA14_Dietrich_B, July 2014, https://doi.org/10.5069/G9MP517V.
EPSG:26910; source GEOID12A elevations in meters. Bed elevation is not water depth.
