from pathlib import Path
import os,json
for key in ['GDAL_DRIVER_PATH','GDAL_DATA','PDAL_DRIVER_PATH','PROJ_LIB','PROJ_DATA']:os.environ.pop(key,None)
from qgis.core import *
from qgis.PyQt.QtGui import QColor
P=Path(__file__).resolve().parent;O=P.parent/'qgis_full_mainstem'
app=QgsApplication([],False);app.initQgis();pr=QgsProject.instance();assert pr.read(str(O/'eel_mainstem_lidar_v2.qgz'));pr.setFilePathStorage(Qgis.FilePathType.Relative);pr.setTitle('Eel River — screened candidate bed v3; channel route v2')
changes={'eel_mainstem_bathy_v2_1m.tif':'eel_mainstem_bathy_v3_1m.tif','eel_mainstem_bathy_v2_1m_support.tif':'eel_mainstem_bathy_v3_1m_support.tif','eel_bed_return_density_v2_1m.tif':'eel_bed_return_density_v3_1m.tif',**{f'eel_roughness_rms_radius{r}m_v2_1m.tif':f'eel_roughness_rms_radius{r}m_v3_1m.tif' for r in [1,2,5]}}
for l in list(pr.mapLayers().values()):
 file=Path(l.source().split('|')[0]).name
 if file in changes:
  ren=l.renderer().clone();l.setDataSource(str(O/changes[file]),l.name().replace('(v2)','')+' (screened v3)','gdal');l.setRenderer(ren)
  if file=='eel_mainstem_bathy_v2_1m.tif':l.elevationProperties().setEnabled(True);l.elevationProperties().setBandNumber(1)
 elif file=='river_centerline_v2.gpkg':
  ren=l.renderer().clone();uri=l.source().replace('river_centerline_v2.gpkg','river_centerline_v3.gpkg');l.setDataSource(uri,l.name()+'; v3 statistics','ogr');l.setRenderer(ren)
original=QgsRasterLayer(str(O/'eel_mainstem_bathy_v2_1m.tif'),'Original v2 candidate bed — unscreened comparison');assert original.isValid();pr.addMapLayer(original);pr.layerTreeRoot().findLayer(original.id()).setItemVisibilityChecked(False);original.elevationProperties().setEnabled(True);original.elevationProperties().setBandNumber(1)
quality=QgsRasterLayer(str(O/'eel_mainstem_bed_quality_v3_1m.tif'),'Return checks v3 — provisional categories');assert quality.isValid()
items=[QgsPalettedRasterRenderer.Class(i,QColor(c),lab) for i,c,lab in [(1,'#207bb0','Below surface; coherent'),(2,'#c88b22','Shallow / surface unresolved'),(3,'#b74055','Above surface'),(4,'#845890','Surface check unavailable'),(5,'#777777','Other unresolved support')]]
quality.setRenderer(QgsPalettedRasterRenderer(quality.dataProvider(),1,items));quality.renderer().setOpacity(.65);pr.addMapLayer(quality);pr.layerTreeRoot().findLayer(quality.id()).setItemVisibilityChecked(False);quality.saveNamedStyle(str(O/'eel_mainstem_bed_quality_v3_1m.qml'))
b=QgsBookmark();b.setName('Audited scoured pool — river km 152.4');extent=QgsReferencedRectangle(QgsRectangle(421530,4469510,421900,4469850),pr.crs());b.setExtent(extent);pr.bookmarkManager().addBookmark(b);pr.viewSettings().setDefaultViewExtent(extent)
out=O/'eel_mainstem_lidar_v3.qgz';assert pr.write(str(out));pr.clear();assert pr.read(str(out));invalid=[l.name() for l in pr.mapLayers().values() if not l.isValid()];assert not invalid;result={'result':'PASS','valid_layers':len(pr.mapLayers()),'project':str(out),'relative_paths':True};(P/'qgis_verification.json').write_text(json.dumps(result,indent=2));print(result);pr.clear()
