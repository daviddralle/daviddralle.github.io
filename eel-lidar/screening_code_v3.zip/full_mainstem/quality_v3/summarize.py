from pathlib import Path
import json
P=Path(__file__).resolve().parent
stats=[json.loads(f.read_text()) for f in (P/'raster_metadata').glob('*.json')]
a={'tiles':len(stats),'original_supported_cells':sum(s.get('original_cells',0) for s in stats),'screened_supported_cells':sum(s['valid_cells'] for s in stats),'direct_cells':sum(s['direct_cells'] for s in stats),'quality_cells':{str(c):sum(s.get('quality_cells',{}).get(str(c),0) for s in stats) for c in range(1,6)},'point_screen':json.loads((P/'point_summary.json').read_text())}
assert a['original_supported_cells']==sum(a['quality_cells'].values())
assert a['screened_supported_cells']==a['quality_cells']['1']+a['quality_cells']['4']
(P/'quality_summary.json').write_text(json.dumps(a,indent=2));print(json.dumps(a,indent=2))
