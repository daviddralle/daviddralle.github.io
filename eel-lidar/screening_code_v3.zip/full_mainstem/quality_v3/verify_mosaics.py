from pathlib import Path
import json,hashlib
import numpy as np,rasterio
from rasterio.windows import Window
P=Path(__file__).resolve().parent;O=P.parent/'qgis_full_mainstem';stats=[json.loads(f.read_text()) for f in (P/'raster_metadata').glob('*.json')];checks=0;counts={}
for folder,suffix,name in [('bathy_tiles','','eel_mainstem_bathy_v3_1m.tif'),('bathy_tiles','_support','eel_mainstem_bathy_v3_1m_support.tif'),('quality_tiles','','eel_mainstem_bed_quality_v3_1m.tif')]:
 count=0
 with rasterio.open(O/name) as mosaic:
  for st in stats:
   path=P/folder/(st['tile']+suffix+'.tif')
   if not path.exists():continue
   x0,y0,x1,y1=st['grid'];win=Window(int(x0-mosaic.bounds.left),int(mosaic.bounds.top-y1),1000,1000)
   with rasterio.open(path) as ds:expected=ds.read(1)
   got=mosaic.read(1,window=win);assert np.array_equal(got,expected),path.name;checks+=1;count+=int((got!=mosaic.nodata).sum())
 counts[name]=count
summary=json.loads((P/'quality_summary.json').read_text());assert counts['eel_mainstem_bathy_v3_1m.tif']==summary['screened_supported_cells'];assert counts['eel_mainstem_bed_quality_v3_1m.tif']==summary['original_supported_cells']
previous=json.loads((P.parents[1]/'viewer/before_quality_v3/build_manifest.json').read_text())['source'];preserved={}
for key,name in [('bed_sha256','eel_mainstem_bathy_v2_1m.tif'),('bank_sha256','eel_mainstem_banks_v2_2m.tif')]:
 h=hashlib.sha256((O/name).read_bytes()).hexdigest();assert h==previous[key];preserved[name]=h
report={'result':'PASS','exact_tile_mosaic_windows_checked':checks,'counts':counts,'original_v2_bed_and_banks_unchanged_sha256':preserved};(P/'mosaic_verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
