"""Source-point and raster audits, including known false pool and shallow returns."""
from pathlib import Path
import json
import numpy as np,rasterio,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent;F=P.parent;O=F/'qgis_full_mainstem'
qa={'checks':[]};counts=np.zeros(3,np.int64);supported=0;no_surface=0;flag_counts=np.zeros(5,np.int64);source=0
for f in (P/'point_flags').glob('*.npz'):
 with np.load(f) as d:a=d['xyz'];flags=d['flag'];depth=d['depth']
 with np.load(P/'bed_points'/f.name) as d:kept=d['class14']
 assert np.array_equal(kept,a[np.isin(flags,[1,4])]);assert np.all(depth[flags==1]>.349999);assert not np.isfinite(depth[flags==4]).any();source+=len(flags)
 for i,t in enumerate([.2,.35,.5]):counts[i]+=int((depth>t).sum())
 supported+=int(np.isfinite(depth).sum());no_surface+=int((~np.isfinite(depth)).sum())
 for c in range(1,6):flag_counts[c-1]+=int((flags==c).sum())
qa.update(point_files_checked=len(list((P/'point_flags').glob('*.npz'))),source_points=source,point_flag_counts=flag_counts.tolist(),surface_model_points=supported,no_surface_model_points=no_surface,separation_sensitivity={'note':'Pre-coherence count at fixed offsets; does not reproduce adaptive 3*MAD screen or establish optimal threshold','threshold_m':[.2,.35,.5],'points_deeper_than_offset':counts.tolist()})
with np.load(P/'point_flags/ot_EelRiver_Aq_000256.npz') as d:a=d['xyz'];flag=d['flag'];depth=d['depth']
m=(a[:,0]>=421705)&(a[:,0]<=421730)&(a[:,1]>=4469650)&(a[:,1]<=4469690)
assert m.sum()>1000 and not np.isin(flag[m],[1,4]).any();qa['false_plateau_point_count']=int(m.sum());qa['false_plateau_all_unresolved_near_surface']=bool((flag[m]==2).all())
winbounds=[421705,4469650,421730,4469690]
with rasterio.open(O/'eel_mainstem_bathy_v3_1m.tif') as ds:
 win=rasterio.windows.from_bounds(*winbounds,ds.transform);z=ds.read(1,window=win);assert (z==-9999).all()
qa['false_plateau_raster_all_nodata']=True
# Shallow observations are preserved as ambiguous, not silently declared errors.
qa['shallow_category_preserved_in_source_flags']=int(flag_counts[1]);qa['shallow_bed_accuracy']='Unknown; no independent surveyed riffle elevations. Original comparison retained; shallow exclusion is explicit.'
fig,axes=plt.subplots(2,2,figsize=(12,8),layout='constrained')
colors={1:'#207bb0',2:'#c88b22',3:'#b74055',4:'#845890',5:'#777777'}
for ax,north in zip(axes[0],[4469670,4469730]):
 mask=(abs(a[:,1]-north)<1)&(a[:,0]>421670)&(a[:,0]<421800)
 for c in [2,3,5,4,1]:
  b=a[mask&(flag==c)];ax.scatter(b[:,0],b[:,2],s=5,color=colors[c],label={1:'Below surface',2:'Shallow / surface unresolved',3:'Above surface',4:'No surface check',5:'Insufficient 3D support'}[c])
 ax.set(xlabel='Easting (m)',ylabel='Source elevation (m)',title=f'Raw returns at N {north:,} ±1 m');ax.ticklabel_format(useOffset=False,style='plain');ax.set_ylim(29.5,34)
axes[0,0].legend(fontsize=7)
for ax,filename,title in zip(axes[1],['eel_mainstem_bathy_v2_1m.tif','eel_mainstem_bathy_v3_1m.tif'],['Original v2: false raised pool interior','Screened v3: unresolved interior stays empty']):
 with rasterio.open(O/filename) as ds:
  bounds=[421630,4469600,421820,4469810];ar=ds.read(1,window=rasterio.windows.from_bounds(*bounds,ds.transform));ax.imshow(np.ma.masked_equal(ar,-9999),extent=[bounds[0],bounds[2],bounds[1],bounds[3]],vmin=30,vmax=33,cmap='viridis');ax.set_title(title,fontsize=10);ax.ticklabel_format(useOffset=False,style='plain');ax.set_xlabel('Easting (m)');ax.set_ylabel('Northing (m)')
fig.savefig(P/'pool152_screening.png',dpi=170);plt.close(fig)
# Independent PCA check for points around selected retained cells.
from scipy.spatial import cKDTree
import screen_points as qc
checks=[]
for stem in ['ot_EelRiver_Aq_000256','ot_EelRiver_Aq_000367']:
 tile=next(t for t in qc.tiles if t['stem']==stem);l,b,r,u=tile['grid'];pieces=[]
 for name in tile['neighbors']:
  with np.load(P/'bed_points'/(name+'.npz')) as d:pts=d['class14']
  m=(pts[:,0]>=l-5.1)&(pts[:,0]<=r+5.1)&(pts[:,1]>=b-5.1)&(pts[:,1]<=u+5.1)
  if m.any():pieces.append(pts[m])
 pts=np.unique(np.vstack(pieces),axis=0);tree=cKDTree(pts[:,:2])
 for radius in [1,2,5]:
  file=P/'roughness_tiles'/(stem+f'_rms_r{radius}m.tif')
  if not file.exists():continue
  with rasterio.open(file) as ds:ar=ds.read(1);tr=ds.transform
  rr,cc=np.nonzero(ar!=-9999)
  for k in np.linspace(0,len(rr)-1,min(6,len(rr))).astype(int):
   y,x=rr[k],cc[k];ids=tree.query_ball_point([tr.c+x+.5,tr.f-y-.5],radius);v=pts[ids];v=v-v.mean(axis=0);expected=np.linalg.svd(v,compute_uv=False)[-1]/np.sqrt(len(v));err=abs(expected-ar[y,x]);assert err<1e-6;checks.append(float(err))
assert len(checks)==36
qa['independent_raw_point_SVD_checks']=len(checks);qa['maximum_PCA_error_m']=max(checks);qa['result']='PASS';(P/'verification.json').write_text(json.dumps(qa,indent=2));print(json.dumps(qa,indent=2))
