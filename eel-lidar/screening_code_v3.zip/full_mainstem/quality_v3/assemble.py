from pathlib import Path
import json,argparse
import numpy as np,rasterio
from rasterio.enums import Resampling
from rasterio.windows import Window
P=Path(__file__).resolve().parent;F=P.parent;O=F/'qgis_full_mainstem';V=F/'centerline_v2'
def oldfile(stem):
 p=V/'merged/bathy_tiles'/(stem+'.tif');return p if p.exists() else F/'bathy_tiles'/(stem+'.tif')
with rasterio.open(O/'eel_mainstem_bathy_v2_1m.tif') as ds:base=ds.profile.copy();left,bottom,right,top=ds.bounds
stats=[json.loads(f.read_text()) for f in sorted((F/'raster_metadata').glob('*.json'))]
products=[('bathy_tiles','','eel_mainstem_bathy_v3_1m.tif','float32',-9999),('bathy_tiles','_support','eel_mainstem_bathy_v3_1m_support.tif','uint8',0),('quality_tiles','','eel_mainstem_bed_quality_v3_1m.tif','uint8',0)]+[('roughness_tiles',f'_rms_r{r}m',f'eel_roughness_rms_radius{r}m_v3_1m.tif','float32',-9999) for r in [1,2,5]]+[('roughness_tiles','_density','eel_bed_return_density_v3_1m.tif','float32',-9999),('roughness_tiles','_neighbors_r1m','eel_roughness_neighbors_radius1m_v3_1m.tif','float32',-9999),('reference','','eel_original_v2_comparison_cm.tif','uint16',0)]
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--reference-only',action='store_true');ap.add_argument('--bed-only',action='store_true');args=ap.parse_args()
 for folder,suffix,name,dtype,nodata in products:
  if args.reference_only and folder!='reference':continue
  if args.bed_only and folder=='roughness_tiles':continue
  path=O/name;done=P/(name+'.done.json')
  if done.exists():continue
  pr=base.copy();pr.update(dtype=dtype,nodata=nodata,compress='deflate',zlevel=9,predictor=3 if dtype=='float32' else 2,BIGTIFF='YES',SPARSE_OK='YES');cells=0
  with rasterio.open(path,'w',**pr) as dst:
   dst.update_tags(source='CA14_Dietrich_B; https://doi.org/10.5069/G9MP517V',screen_version='source-screen-v3' if folder!='reference' else 'original-v2-display-only',method_file='quality_v3/method.json',vertical_reference='Source GEOID12A heights, meters',warning='Exploratory screening, not validated bathymetry; near-surface/shallow unresolved; unknown depth is NoData; retained cells without water-surface support are flagged 4; see quality TIFF')
   if folder=='reference':dst.update_tags(decode='elevation_m = encoded_value / 100 - 1; 0 = NoData',rounding_error_max_m='0.005',purpose='Original v2 comparison only. Full-precision original GeoTIFF is preserved separately.')
   for st in stats:
    stem=st['tile'];src=oldfile(stem) if folder=='reference' else P/folder/(stem+suffix+'.tif')
    if not src.exists():continue
    with rasterio.open(src) as ds:a=ds.read(1)
    if folder=='reference':valid=a!=-9999;values=np.rint((a[valid]+1)*100);assert values.min(initial=1)>0 and values.max(initial=1)<65535;a=np.where(valid,np.rint((a+1)*100),0).astype('uint16')
    cells+=int((a!=nodata).sum());x0,y0,x1,y1=st['grid'];dst.write(a,1,window=Window(int(x0-left),int(top-y1),1000,1000))
   dst.build_overviews([4,16,64,256,1024],Resampling.nearest)
  done.write_text(json.dumps({'file':name,'cells':cells,'bytes':path.stat().st_size}));print(name,cells,path.stat().st_size,flush=True)
