"""Rebuild TIN and PCA from screened points. Keep v2 geometry and original files."""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:os.environ[key]='1'
from pathlib import Path
import importlib.util,json,time,argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
import numpy as np,rasterio
from rasterio.enums import Resampling
from shapely.geometry import shape
import screen_points as qc
P=Path(__file__).resolve().parent;F=P.parent;V=F/'centerline_v2'
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
bed=module('bed_v3',F/'rasterize_bed.py');bed.P=P
# Keep the original corridor and corrected bend recovery, then restrict to v2 support.
bed.corridor=bed.corridor.union(qc.route.buffer(160))
rough=module('rough_v3',F/'roughness_corridor.py');rough.P=P
byname={t['stem']:t for t in qc.tiles};v=np.load(P/'surface_bins.npz')['bins']
def oldfile(folder,name):
 p=V/'merged'/folder/name;return p if p.exists() else F/folder/name

def work(t):
 stem=t['stem'];meta=P/'raster_metadata'/(stem+'.json');finished=P/'quality_tiles'/(stem+'.json')
 if finished.exists():return json.loads(finished.read_text())
 result=bed.work(t);old=oldfile('bathy_tiles',stem+'.tif')
 if not old.exists():
  assert result['valid_cells']==0, 'Unexpected support outside original v2 footprint'
  finished.write_text(json.dumps(result));return result
 with rasterio.open(old) as ds:orig=ds.read(1);profile=ds.profile;tr=ds.transform
 with rasterio.open(oldfile('bathy_tiles',stem+'_support.tif')) as ds:osup=ds.read(1)
 bp=P/'bathy_tiles'/(stem+'.tif');sp=P/'bathy_tiles'/(stem+'_support.tif')
 if bp.exists():
  with rasterio.open(bp) as ds:new=ds.read(1)
  with rasterio.open(sp) as ds:sup=ds.read(1)
 else:new=np.full(orig.shape,-9999,np.float32);sup=np.zeros(orig.shape,np.uint8)
 new[osup==0]=-9999;sup[osup==0]=0
 r,c=np.nonzero(osup);xy=np.c_[tr.c+c+.5,tr.f-r-.5];water=qc.load_halo(byname[stem])[15];wse,tol=qc.surface_at(xy,water,v);d=wse-orig[r,c]
 # Codes refer to the displayed raster: qualified submerged, ambiguous near
 # surface, above surface, retained but unscreened, other unresolved gap.
 flags=np.full(len(r),5,np.uint8);known=np.isfinite(wse);flags[known&(abs(d)<=tol)]=2;flags[known&(d < -tol)]=3
 got=new[r,c]!=-9999;flags[got&known]=1;flags[got&~known]=4
 # Guard interpolation from producing a new near-surface value.
 reject=got&known&((wse-new[r,c])<=tol);new[r[reject],c[reject]]=-9999;sup[r[reject],c[reject]]=0;flags[reject]=2
 quality=np.zeros(orig.shape,np.uint8);quality[r,c]=flags
 for path,a,nodata in [(bp,new,-9999),(sp,sup,0),(P/'quality_tiles'/(stem+'.tif'),quality,0)]:
  pr=profile.copy();pr.update(dtype=str(a.dtype),nodata=nodata,predictor=3 if a.dtype.kind=='f' else 2,compress='deflate')
  with rasterio.open(path,'w',**pr) as dst:
   dst.write(a,1);dst.update_tags(screen_version='source-screen-v3',method_file='quality_v3/method.json',source='CA14_Dietrich_B; https://doi.org/10.5069/G9MP517V',warning='Conservative provisional screen, not validated bed. Ambiguous shallow/surface returns excluded. NoData is unknown, not zero depth. No added refraction correction.')
   if path.parent.name=='quality_tiles':dst.set_band_description(1,'1 below surface; 2 shallow/surface ambiguous; 3 above surface; 4 no surface check; 5 unresolved support; 0 no original bed')
   dst.build_overviews([2,4,8,16],Resampling.nearest)
 zz=new[new!=-9999];result['z_range']=[float(zz.min()),float(zz.max())] if len(zz) else None
 result.update(valid_cells=int((sup>0).sum()),direct_cells=int((sup==1).sum()),interpolated_cells=int((sup==2).sum()),original_cells=int((osup>0).sum()),quality_cells={str(i):int((quality==i).sum()) for i in range(1,6)})
 meta.write_text(json.dumps(result));finished.write_text(json.dumps(result));return result

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--tile');ap.add_argument('--stage',choices=['bed','rough','all'],default='all');ap.add_argument('--workers',type=int,default=3);args=ap.parse_args()
 for stage,mod,fn in [('bed',bed,work),('rough',rough,rough.work)]:
  if args.stage not in [stage,'all']:continue
  targets=[t for t in mod.tiles if not args.tile or t['stem']==args.tile];start=time.time()
  with ThreadPoolExecutor(max_workers=args.workers) as pool:
   for j,f in enumerate(as_completed([pool.submit(fn,t) for t in targets])):
    s=f.result()
    if j%10==0 or j==len(targets)-1:print(stage,j+1,'/',len(targets),'seconds',round(time.time()-start),s,flush=True)
