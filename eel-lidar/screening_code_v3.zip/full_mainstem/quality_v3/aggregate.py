"""Same v2 channel geometry; reassigned screened bed, quality, and raw-point PCA."""
from pathlib import Path
import json
P=Path(__file__).resolve().parent;F=P.parent;V=F/'centerline_v2'
s=(V/'reassign.py').read_text()
s=s.replace("P=Path(__file__).parent;F=P.parent;O=F/'qgis_full_mainstem'", "P=Path(__file__).resolve().parent;F=P.parent;V=F/'centerline_v2';O=F/'qgis_full_mainstem'")
s=s.replace("P/'route_final.geojson'","V/'route_final.geojson'").replace("P/'intervals.json'","V/'intervals.json'").replace("P/'reference_route.geojson'","V/'reference_route.geojson'")
a=s.index('def source(folder,name):');b=s.index('stats=',a)
s=s[:a]+"def source(folder,name):return P/folder/name\n"+s[b:]
s=s.replace("(F/'raster_metadata').glob", "(P/'raster_metadata').glob")
s=s.replace("'eel_mainstem_interval_ids_v2_1m.tif'","'eel_mainstem_interval_ids_v3_1m.tif'").replace("'roughness_predictors_100m_v2.csv'","'roughness_predictors_100m_v3.csv'").replace("'river_centerline_v2.gpkg'","'river_centerline_v3.gpkg'")
s=s.replace('areas=np.zeros(n,np.int64);', 'qualityareas=np.zeros((5,n),np.int64);areas=np.zeros(n,np.int64);')
s=s.replace("if not s['valid_cells']:continue", """qfile=P/'quality_tiles'/(s['tile']+'.tif')
  if qfile.exists():
   with rasterio.open(qfile) as ds:qa=ds.read(1);qt=ds.transform
   qr,qc=np.nonzero(qa);qxy=np.c_[qt.c+qc+.5,qt.f-qr-.5];qs,qd=locate(qxy);qb=np.minimum((qs/100).astype(int),n-1);qkeep=qd<=limits[qb]
   for code in range(1,6):qualityareas[code-1]+=np.bincount(qb[qkeep&(qa[qr,qc]==code)],minlength=n)
  if not s['valid_cells']:continue""")
s=s.replace("for radius in [1,2,5]:\n  v=np.concatenate", "r.update({f'quality_{c}_area_m2':int(qualityareas[c-1,j]) for c in range(1,6)});r['original_bed_area_m2']=int(qualityareas[:,j].sum());r['screened_fraction_of_original_bed']=float(areas[j]/r['original_bed_area_m2']) if r['original_bed_area_m2'] else None\n for radius in [1,2,5]:\n  v=np.concatenate")
s=s.replace("'Original supported raster values are preserved; newly recovered class-14 bed cells were added using the original methods. Interval assignment follows the v2 route. Uncertain interval statistics remain available with flags but are omitted from the default viewer profile.'", "'Bed and all PCA neighborhoods rebuilt from screened points. Geometry remains route v2. Original v2 files preserved separately. Quality areas are fractions of original supported candidate bed, not full channel.'")
s=s.replace("(P/'reassignment_qa.json')", "assert np.array_equal(qualityareas[0]+qualityareas[3],areas)\nsummary['quality_assigned_cells']={str(c):int(qualityareas[c-1].sum()) for c in range(1,6)}\n(P/'reassignment_qa.json')")
s=s.replace("table=pd.DataFrame(records);", "oldtable=pd.read_csv(O/'roughness_predictors_100m_v2.csv').set_index('interval_id')\nfor rec in records:\n old=oldtable.loc[rec['interval_id']];assert abs(old.river_km-rec['river_km'])<1e-6;assert int(old.supported_bed_area_m2)==rec['original_bed_area_m2']\n for radius in [1,2,5]:\n  for stat in ['median_m','p90_m','ncells']:\n   key=f'rough_r{radius}_{stat}';value=old[key];rec['original_v2_'+key]=None if pd.isna(value) else float(value)\ntable=pd.DataFrame(records);")
(P/'reassign_generated.py').write_text(s)
exec(compile(s,str(P/'reassign_generated.py'),'exec'),{'__file__':str(P/'reassign_generated.py'),'__name__':'__main__'})
