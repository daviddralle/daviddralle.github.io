"""Conservative source-point screening; ambiguous shallow returns are NOT called errors.
Classes 14/15 are provisional candidate bed/surface. Original files are immutable.
"""
from pathlib import Path
import json,time,argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import shape,box
from threadpoolctl import threadpool_limits
threadpool_limits(1)
P=Path(__file__).resolve().parent;F=P.parent;V=F/'centerline_v2';CACHE=V/'recovered/bed_points'
for name in ['bed_points','point_flags','point_metadata','bathy_tiles','raster_metadata','roughness_tiles','roughness_metadata','quality_tiles']:(P/name).mkdir(exist_ok=True)
tiles=json.loads((F/'download_manifest.json').read_text())
for t in tiles:
 t['stem']=Path(t['Filename']).stem;x,y,*_=t['bounds'];l,b=np.floor(x/1000)*1000,np.floor(y/1000)*1000;t['grid']=[l,b,l+1000,b+1000]
 t['neighbors']=[Path(n['Filename']).stem for n in tiles if box(*n['bounds']).intersects(box(*t['grid']).buffer(41))]
route=shape(json.loads((V/'route_final.geojson').read_text())['features'][0]['geometry'])
station=np.arange(0,route.length+1,2);axis=np.array([route.interpolate(float(s)).coords[0] for s in station]);axis_tree=cKDTree(axis)
intervals=json.loads((V/'intervals.json').read_text());width=np.array([i['channel_width_m'] for i in intervals]);limit=np.clip(width/2+15,25,300)
CONFIG={'version':'source-screen-v3','source_classes':'14 candidate bed; 15 candidate water surface; interpretations provisional','surface_bin_m':10,'surface_bin_min_points':10,'surface_bin_max_scaled_MAD_m':.20,'surface_interpolation_max_gap_m':60,'surface_max_XY_distance_m':40,'minimum_surface_separation_m':.35,'separation_MAD_multiplier':3,'coherence_ellipsoid_XY_radius_m':2,'coherence_ellipsoid_Z_radius_m':.30,'coherence_min_distinct_points_including_self':5,'classes':{'1':'Coherent and below estimated surface by more than tolerance; provisional bed','2':'Within surface tolerance: shallow bed or surface return, unresolved','3':'Above estimated surface by more than tolerance','4':'Coherent candidate bed, local surface check unavailable','5':'Insufficient local 3D support (isolated or steep/rough), unresolved'},'retained_point_classes':[1,4],'roughness_warning':'Screen changes sampled depths and coverage. Near-surface/shallow returns excluded rather than declared erroneous. Not a calibrated classifier or field validation.'}
(P/'method.json').write_text(json.dumps(CONFIG,indent=2))
def locate(xy):
 d,i=axis_tree.query(xy,workers=1);s=station[i];bins=np.minimum((s/100).astype(int),len(limit)-1);return s,d,limit[bins]
def surface_bins():
 out=P/'surface_bins.npz'
 if out.exists():return
 pieces=[]
 for j,t in enumerate(tiles):
  with np.load(CACHE/(t['stem']+'.npz')) as d:w=d['class15']
  if len(w):
   s,dist,lim=locate(w[:,:2]);keep=dist<=lim;pieces.append(np.c_[(s[keep]//10).astype(int),w[keep,2]])
  if j%60==0:print('surface collection',j,len(tiles),flush=True)
 a=np.vstack(pieces);order=np.argsort(a[:,0]);a=a[order];cuts=np.r_[0,np.flatnonzero(np.diff(a[:,0]))+1,len(a)];rows=[]
 for lo,hi in zip(cuts[:-1],cuts[1:]):
  z=a[lo:hi,1];med=np.median(z);mad=1.4826*np.median(abs(z-med))
  if len(z)>=10 and mad<=.20:rows.append([a[lo,0]*10+5,med,mad,len(z)])
 v=np.array(rows);np.savez_compressed(out,bins=v);np.savetxt(P/'surface_bins.csv',v,delimiter=',',header='station_m,surface_z_m,scaled_MAD_m,n',comments='');print('surface bins',len(v),flush=True)

def surface_at(xy,water,v):
 s,d,lim=locate(xy);si=v[:,0];ix=np.searchsorted(si,s);i0=np.clip(ix-1,0,len(si)-1);i1=np.clip(ix,0,len(si)-1)
 valid=(s>=si[0])&(s<=si[-1])&((si[i1]-si[i0])<=60)&(d<=lim)
 if len(water):valid &= cKDTree(water[:,:2]).query(xy,workers=1)[0]<=40
 else:valid[:]=False
 z=np.interp(s,si,v[:,1]);z[~valid]=np.nan;tol=np.maximum(.35,3*np.maximum(v[i0,2],v[i1,2]));return z,tol

def load_halo(t,halo=41):
 l,b,r,u=t['grid'];pieces={14:[],15:[]}
 for name in t['neighbors']:
  with np.load(CACHE/(name+'.npz')) as data:
   for code in [14,15]:
    a=data['class'+str(code)];m=(a[:,0]>=l-halo)&(a[:,0]<=r+halo)&(a[:,1]>=b-halo)&(a[:,1]<=u+halo)
    if m.any():pieces[code].append(a[m])
 return {c:np.unique(np.vstack(p),axis=0) if p else np.empty((0,3)) for c,p in pieces.items()}

def work(t):
 stem=t['stem'];dest=P/'point_metadata'/(stem+'.json')
 if dest.exists():return json.loads(dest.read_text())
 start=time.time();v=np.load(P/'surface_bins.npz')['bins'];halo=load_halo(t);b=halo[14];w=halo[15]
 with np.load(CACHE/(stem+'.npz')) as data:own=np.unique(data['class14'],axis=0);surface=data['class15']
 flags=np.full(len(own),4,dtype=np.uint8);depth=np.full(len(own),np.nan,dtype=np.float32)
 if len(own):
  wse,tol=surface_at(own[:,:2],w,v);depth=wse-own[:,2];valid=np.isfinite(wse)
  flags[valid&(depth>tol)]=1;flags[valid&(abs(depth)<=tol)]=2;flags[valid&(depth < -tol)]=3
  # 3D coherence is evaluated among points from the same water-surface category,
  # so a dense surface layer cannot lend support to an isolated lower return.
  bwse,btol=surface_at(b[:,:2],w,v);bd=bwse-b[:,2];bkeep=~np.isfinite(bwse)|(bd>btol)
  eligible=np.flatnonzero((flags==1)|(flags==4));ref=b[bkeep];origin=np.array([t['grid'][0],t['grid'][1],0]);scale=np.array([2.,2.,.30])
  if len(ref):
   tree=cKDTree((ref-origin)/scale);counts=tree.query_ball_point((own[eligible]-origin)/scale,1,return_length=True,workers=1);flags[eligible[counts<5]]=5
  else:flags[eligible]=5
 keep=(flags==1)|(flags==4)
 np.savez_compressed(P/'bed_points'/(stem+'.npz'),class14=own[keep],class15=surface)
 np.savez_compressed(P/'point_flags'/(stem+'.npz'),xyz=own,flag=flags,depth=depth)
 stats={'tile':stem,'grid':t['grid'],'source_distinct_points':len(own),'retained_points':int(keep.sum()),'counts':{str(c):int((flags==c).sum()) for c in range(1,6)},'elapsed_s':round(time.time()-start,2)};dest.write_text(json.dumps(stats));return stats
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--tile');parser.add_argument('--workers',type=int,default=3);args=parser.parse_args();surface_bins();targets=[t for t in tiles if not args.tile or t['stem']==args.tile]
 start=time.time()
 with ThreadPoolExecutor(max_workers=args.workers) as pool:
  for j,f in enumerate(as_completed([pool.submit(work,t) for t in targets])):
   s=f.result()
   if j%10==0 or j==len(targets)-1:print('screened',j+1,'/',len(targets),s,flush=True)
 stats=[json.loads(p.read_text()) for p in (P/'point_metadata').glob('*.json')];summary={'completed_tiles':len(stats),'source_distinct_points':sum(s['source_distinct_points'] for s in stats),'retained_points':sum(s['retained_points'] for s in stats),'point_classes':{str(c):sum(s['counts'][str(c)] for s in stats) for c in range(1,6)},'elapsed_s':time.time()-start};(P/'point_summary.json').write_text(json.dumps(summary,indent=2));print(summary,flush=True)
