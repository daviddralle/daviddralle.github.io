from pathlib import Path
import json,time,traceback
from concurrent.futures import ThreadPoolExecutor,as_completed
import numpy as np
from threadpoolctl import threadpool_limits
threadpool_limits(limits=1)
from scipy.spatial import Delaunay,cKDTree
import rasterio
from rasterio.transform import from_origin
from rasterio.features import rasterize
from rasterio.enums import Resampling
from shapely.geometry import box,shape,mapping

P=Path(__file__).parent
for d in ['bathy_tiles','raster_metadata']:(P/d).mkdir(exist_ok=True)
tiles=json.loads((P/'download_manifest.json').read_text())
corridor=shape(json.loads((P/'corridor_utm.geojson').read_text())['features'][0]['geometry'])
for t in tiles:
 stem=Path(t['Filename']).stem;t['stem']=stem
 # Source point bounds are rounded onto the original 1 km delivery grid.
 x0,y0,x1,y1=t['bounds'];t['grid']=[np.floor(x0/1000)*1000,np.floor(y0/1000)*1000,np.floor(x0/1000)*1000+1000,np.floor(y0/1000)*1000+1000]
 t['neighbors']=[Path(n['Filename']).stem for n in tiles if box(*n['bounds']).intersects(box(*t['grid']).buffer(3.1))]

def work(t):
 stem=t['stem'];meta=P/'raster_metadata'/(stem+'.json')
 if meta.exists():return json.loads(meta.read_text())
 left,bottom,right,top=t['grid'];pieces=[]
 for name in t['neighbors']:
  with np.load(P/'bed_points'/(name+'.npz')) as d:b=d['class14']
  if len(b):
   m=(b[:,0]>=left-3.1)&(b[:,0]<=right+3.1)&(b[:,1]>=bottom-3.1)&(b[:,1]<=top+3.1)
   if m.any():pieces.append(b[m])
 points=np.vstack(pieces) if pieces else np.empty((0,3));stats={'tile':stem,'input_class14_with_halo':len(points),'valid_cells':0,'direct_cells':0,'interpolated_cells':0,'grid':t['grid'],'z_range':None}
 if len(points)<3:meta.write_text(json.dumps(stats));return stats
 xy,inverse=np.unique(points[:,:2],axis=0,return_inverse=True)
 z=np.bincount(inverse,weights=points[:,2])/np.bincount(inverse)
 local=xy-[left,bottom]
 if len(local)<3 or np.linalg.matrix_rank(local-local.mean(axis=0))<2:meta.write_text(json.dumps(stats));return stats
 tri=Delaunay(local)
 trans=from_origin(left,top,1,1)
 mask=rasterize([(mapping(corridor.intersection(box(left,bottom,right,top))),1)],out_shape=(1000,1000),transform=trans).astype(bool)
 r,c=np.nonzero(mask);q=np.column_stack([c+.5,1000-r-.5]);near=cKDTree(local).query(q,workers=1)[0]
 simplex=tri.find_simplex(q);ok=(simplex>=0)&(near<=1.5)
 idx=np.flatnonzero(ok);s=simplex[idx];v=local[tri.simplices[s]]
 edge=np.maximum.reduce([np.linalg.norm(v[:,0]-v[:,1],axis=1),np.linalg.norm(v[:,0]-v[:,2],axis=1),np.linalg.norm(v[:,1]-v[:,2],axis=1)])
 idx=idx[edge<=3];s=simplex[idx]
 w=np.einsum('nij,nj->ni',tri.transform[s,:2],q[idx]-tri.transform[s,2]);w=np.column_stack([w,1-w.sum(axis=1)])
 values=np.einsum('ni,ni->n',w,z[tri.simplices[s]])
 assert (w>=-1e-7).all() and (w<=1+1e-7).all()
 raster=np.full((1000,1000),-9999,dtype='float32');raster[r[idx],c[idx]]=values
 counts=np.zeros((1000,1000),dtype='uint32')
 pr=np.floor(top-points[:,1]).astype(int);pc=np.floor(points[:,0]-left).astype(int);valid=(pr>=0)&(pr<1000)&(pc>=0)&(pc<1000)
 np.add.at(counts,(pr[valid],pc[valid]),1)
 support=np.zeros((1000,1000),dtype='uint8');support[(raster!=-9999)&(counts>0)]=1;support[(raster!=-9999)&(counts==0)]=2
 profile=dict(driver='GTiff',width=1000,height=1000,count=1,crs='EPSG:26910',transform=trans,tiled=True,blockxsize=256,blockysize=256,compress='deflate')
 tags={'source':'NCALM CA14_Dietrich_B; https://doi.org/10.5069/G9MP517V','source_class':'14 — provisional bathymetric bed','vertical_reference':'Source GEOID12A heights, meters','method':'1 m linear TIN; triangle longest edge <=3 m; nearest return <=1.5 m; 3.1 m neighboring-tile halo','warning':'Exploratory bed elevation, not water depth. Unsupported cells are NoData. No new refraction or registration correction.'}
 for suffix,a,dtype,nodata in [('',raster,'float32',-9999),('_support',support,'uint8',0)]:
  path=P/'bathy_tiles'/(stem+suffix+'.tif');temp=path.with_suffix('.partial.tif')
  with rasterio.open(temp,'w',**profile,dtype=dtype,nodata=nodata,predictor=3 if dtype=='float32' else 2) as dst:
   dst.write(a,1);dst.update_tags(**tags);dst.set_band_description(1,'Bed elevation (m)' if not suffix else '1 source points in cell; 2 local interpolation; 0 NoData')
   if not suffix:dst.set_band_unit(1,'m')
   dst.build_overviews([2,4,8,16],Resampling.nearest)
  temp.replace(path)
 stats.update(valid_cells=len(values),direct_cells=int((support==1).sum()),interpolated_cells=int((support==2).sum()),z_range=[float(values.min()),float(values.max())] if len(values) else None,max_nearest_m=float(near[idx].max()) if len(idx) else None)
 meta.write_text(json.dumps(stats));return stats

if __name__=='__main__':
 completed=set();errors={};start=time.time()
 with ThreadPoolExecutor(max_workers=4) as pool:
  while len(completed)<len(tiles):
   ready=[t for t in tiles if t['stem'] not in completed and all((P/'tile_metadata'/(s+'.json')).exists() for s in t['neighbors'])]
   for f in as_completed({pool.submit(work,t):t for t in ready}):
    result=f.result();completed.add(result['tile'])
   allstats=[json.loads(f.read_text()) for f in (P/'raster_metadata').glob('*.json')]
   state={'completed_tiles':len(completed),'total_tiles':len(tiles),'supported_bed_cells_m2':sum(s['valid_cells'] for s in allstats),'elapsed_s':round(time.time()-start,1)}
   (P/'raster_progress.json').write_text(json.dumps(state,indent=2));print(json.dumps(state),flush=True)
   if len(completed)<len(tiles):time.sleep(10)
 print('All bathymetry tiles completed',flush=True)
