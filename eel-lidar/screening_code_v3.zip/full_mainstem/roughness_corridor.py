"""Multiscale roughness computed from discrete bed points, never from a DEM."""
from pathlib import Path
import json,time
from concurrent.futures import ThreadPoolExecutor,as_completed
import numpy as np
from threadpoolctl import threadpool_limits
threadpool_limits(limits=1)
from scipy.spatial import cKDTree
from numba import njit
import rasterio
from rasterio.transform import from_origin
from rasterio.enums import Resampling
from shapely.geometry import box
P=Path(__file__).parent
for d in ['roughness_tiles','roughness_metadata']:(P/d).mkdir(exist_ok=True)
tiles=json.loads((P/'download_manifest.json').read_text())
for t in tiles:
 t['stem']=Path(t['Filename']).stem;x,y,_,_=t['bounds'];left=np.floor(x/1000)*1000;bottom=np.floor(y/1000)*1000;t['grid']=[left,bottom,left+1000,bottom+1000]
 t['neighbors']=[Path(n['Filename']).stem for n in tiles if box(*n['bounds']).intersects(box(*t['grid']).buffer(5.1))]

@njit(nogil=True,cache=True)
def local_metrics(points,indices,offsets):
 out=np.full(len(offsets)-1,np.nan);aspect=out.copy()
 for j in range(len(out)):
  lo,hi=offsets[j],offsets[j+1];n=hi-lo
  if n<10:continue
  origin=points[indices[lo]];mean=np.zeros(3)
  for k in range(lo,hi):mean+=points[indices[k]]-origin
  mean/=n;cov=np.zeros((3,3))
  for k in range(lo,hi):
   d=points[indices[k]]-origin-mean
   for a in range(3):
    for b in range(3):cov[a,b]+=d[a]*d[b]
  eig=np.linalg.eigvalsh(cov/n)
  if eig[2]<=0:continue
  aspect[j]=eig[1]/eig[2]
  if aspect[j]>=.01:out[j]=np.sqrt(max(0.,eig[0]))
 return out
# Compile once before worker threads start.
local_metrics(np.array([[0.,0.,0.],[1.,0.,0.],[0.,1.,0.]]),np.array([0,1,2],dtype=np.int64),np.array([0,3],dtype=np.int64))

def work(t):
 stem=t['stem'];dest=P/'roughness_metadata'/(stem+'.json')
 if dest.exists():return json.loads(dest.read_text())
 start=time.time();left,bottom,right,top=t['grid'];pieces=[]
 for name in t['neighbors']:
  with np.load(P/'bed_points'/(name+'.npz')) as data:a=data['class14']
  m=(a[:,0]>=left-5.1)&(a[:,0]<=right+5.1)&(a[:,1]>=bottom-5.1)&(a[:,1]<=top+5.1)
  if m.any():pieces.append(a[m])
 points=np.unique(np.vstack(pieces),axis=0) if pieces else np.empty((0,3))
 result={'tile':stem,'grid':t['grid'],'distinct_xyz_points_with_halo':len(points),'density_eligible_cells':0,'valid_cells':{},'elapsed_s':0}
 bathymeta=json.loads((P/'raster_metadata'/(stem+'.json')).read_text())
 if not len(points) or not bathymeta['valid_cells']:
  result['elapsed_s']=round(time.time()-start,2);dest.write_text(json.dumps(result));return result
 rows=np.floor(top-points[:,1]).astype(int);cols=np.floor(points[:,0]-left).astype(int);inside=(rows>=0)&(rows<1000)&(cols>=0)&(cols<1000)
 counts=np.bincount(rows[inside]*1000+cols[inside],minlength=1000000).reshape(1000,1000)
 with rasterio.open(P/'bathy_tiles'/(stem+'_support.tif')) as ds:bed=ds.read(1)>0
 eligible=(counts>=5)&bed;r,c=np.nonzero(eligible);q=np.column_stack([left+c+.5,top-r-.5]);result['density_eligible_cells']=len(q)
 profile=dict(driver='GTiff',width=1000,height=1000,count=1,dtype='float32',nodata=-9999,crs='EPSG:26910',transform=from_origin(left,top,1,1),tiled=True,blockxsize=256,blockysize=256,compress='deflate',predictor=3)
 def save(suffix,array,description,unit):
  file=P/'roughness_tiles'/(stem+'_'+suffix+'.tif');tmp=file.with_suffix('.partial.tif')
  with rasterio.open(tmp,'w',**profile) as dst:
   dst.write(array.astype('float32'),1);dst.set_band_description(1,description);dst.set_band_unit(1,unit)
   dst.update_tags(source='CA14_Dietrich_B, class 14 provisional bed',method='PCA orthogonal plane residual RMS in horizontal disk around each 1 m cell center; >=5 distinct XYZ returns in cell, >=10 neighborhood points, lambda2/lambda3>=0.01; original bed points, not DEM elevations',warning='Uncalibrated surface roughness, not grain size or Manning n; includes sensor/strip/water-column effects; missingness may be related to depth')
   dst.build_overviews([2,4,8,16],Resampling.average)
  tmp.replace(file)
 density=np.where(bed,counts,-9999);save('density',density,'Distinct XYZ bed return density','points/m2')
 if len(q):
  origin=np.array([left,bottom]);tree=cKDTree(points[:,:2]-origin)
  for radius in [1,2,5]:
   values=np.full(len(q),np.nan);nvalues=np.zeros(len(q),dtype=int)
   for begin in range(0,len(q),4000):
    lists=tree.query_ball_point(q[begin:begin+4000]-origin,radius,workers=1);lengths=np.array([len(a) for a in lists],dtype=np.int64);offsets=np.r_[0,np.cumsum(lengths)]
    ids=np.concatenate(lists).astype(np.int64) if offsets[-1] else np.empty(0,dtype=np.int64)
    values[begin:begin+len(lists)]=local_metrics(points,ids,offsets);nvalues[begin:begin+len(lists)]=lengths
   a=np.full((1000,1000),-9999,dtype='float32');ok=np.isfinite(values);a[r[ok],c[ok]]=values[ok]
   save(f'rms_r{radius}m',a,f'Detrended bed roughness RMS (m), horizontal radius {radius} m','m')
   result['valid_cells'][str(radius)]=int(ok.sum())
   if radius==1:
    neighbors=np.full((1000,1000),-9999,dtype='float32');neighbors[r,c]=nvalues;save('neighbors_r1m',neighbors,'Neighborhood point count, radius 1 m','points')
 result['elapsed_s']=round(time.time()-start,2);dest.write_text(json.dumps(result));return result

if __name__=='__main__':
 done=set();start=time.time()
 with ThreadPoolExecutor(max_workers=2) as pool:
  while len(done)<len(tiles):
   ready=[t for t in tiles if t['stem'] not in done and (P/'raster_metadata'/(t['stem']+'.json')).exists() and all((P/'tile_metadata'/(s+'.json')).exists() for s in t['neighbors'])]
   for f in as_completed({pool.submit(work,t):t for t in ready}):done.add(f.result()['tile'])
   state={'completed_tiles':len(done),'total_tiles':len(tiles),'elapsed_s':round(time.time()-start,1)};(P/'roughness_progress.json').write_text(json.dumps(state,indent=2));print(json.dumps(state),flush=True)
   if len(done)<len(tiles):time.sleep(10)
 print('Roughness tiles complete',flush=True)
