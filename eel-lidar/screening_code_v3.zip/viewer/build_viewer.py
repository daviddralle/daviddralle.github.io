from pathlib import Path
import json,base64,hashlib
import fiona,numpy as np
from shapely.geometry import shape
from pyproj import Transformer
P=Path(__file__).parent;S=P.parent/'full_mainstem/qgis_full_mainstem'
tr=Transformer.from_crs(26910,4326,always_xy=True)
rows=[]
with fiona.open(S/'river_centerline_v3.gpkg',layer='roughness_corrected_100m') as src:
 for f in src:
  props=dict(f.properties);g=shape(f.geometry);xy=np.array(g.coords);ll=np.column_stack(tr.transform(xy[:,0],xy[:,1]));mid=g.interpolate(.5,normalized=True);lon,lat=tr.transform(mid.x,mid.y)
  rows.append({'km':round(props['river_km'],5),'len':round(g.length,3),'xy':xy.round(3).tolist(),'ll':ll.round(7).tolist(),'center':[round(lat,7),round(lon,7)],'median':[props[f'rough_r{r}_median_m'] for r in [1,2,5]],'p90':[props[f'rough_r{r}_p90_m'] for r in [1,2,5]],'coverage':[props[f'rough_r{r}_fraction_of_supported_bed'] for r in [1,2,5]],'n':[int(props[f'rough_r{r}_ncells']) for r in [1,2,5]],'density':props['bed_mean_return_density'],'area':props['supported_bed_area_m2'],'quality':props['status'],'auto':bool(props['auto_ok']),'refKm':props['reference_km'],'offset':props['reference_offset_m'],'waterSupport':props['water_fraction'],'width':props['channel_width_m'],'qc':[props[f'quality_{c}_area_m2'] for c in range(1,6)],'originalArea':props['original_bed_area_m2']})
meta={'source':'CA14_Dietrich_B, NCALM / OpenTopography','doi':'https://doi.org/10.5069/G9MP517V','crs':'EPSG:26910','vertical':'Source GEOID12A elevations, meters','route_km':sum(r['len'] for r in rows)/1000,'date':'July 2014','raster_bounds':[388000,4391000,447000,4501000],'raster_resolution_m':1,'nodata':-9999,'bed_sha256':hashlib.sha256((S/'eel_mainstem_bathy_v3_1m.tif').read_bytes()).hexdigest()}
meta['bank_sha256']=hashlib.sha256((S/'eel_mainstem_banks_v2_2m.tif').read_bytes()).hexdigest()
meta['bank_method']=json.loads((P.parent/'full_mainstem/banks/summary.json').read_text())
meta['bank_recovery_qa']=json.loads((P.parent/'full_mainstem/centerline_v2/bank_recovery_qa.json').read_text())
meta['route_version']='lidar2014-v2'
meta['bed_quality_version']='source-screen-v3'
meta['quality_method']=json.loads((P.parent/'full_mainstem/quality_v3/method.json').read_text())
meta['quality_summary']=json.loads((P.parent/'full_mainstem/quality_v3/quality_summary.json').read_text())
meta['recovery_qa']=json.loads((P.parent/'full_mainstem/centerline_v2/recovery_qa.json').read_text())
meta['route_qa']=json.loads((P.parent/'full_mainstem/centerline_v2/route_qa.json').read_text())
meta['assignment_qa']=json.loads((P.parent/'full_mainstem/quality_v3/reassignment_qa.json').read_text())
meta['route_km']=meta['route_qa']['route_length_m']/1000
old=shape(json.loads((P.parent/'full_mainstem/centerline_v2/reference_route.geojson').read_text()))
oldxy=np.asarray(old.coords);oldll=np.column_stack(tr.transform(oldxy[:,0],oldxy[:,1])).round(7).tolist()
data=json.dumps({'meta':meta,'rows':rows,'reference':oldll},separators=(',',':'),allow_nan=False)
(P/'data.json').write_text(data)
html=(P/'template.html').read_text().replace('{{ROUTE_KM}}',f"{meta['route_km']:.1f}").replace('{{PANE_CSS}}',(P/'resize_panels.css').read_text())
for name in ['leaflet.css','leaflet.js','plotly.min.js','proj4.js','geotiff.js']:
 html=html.replace('{{'+name+'}}',(P/'vendor'/name).read_text().replace('</script','<\\/script'))
html=html.replace('{{DATA}}',data.replace('</','<\\/'))
for name,file in [('BATHY','eel_mainstem_bathy_v3_1m.tif'),('SUPPORT','eel_mainstem_bathy_v3_1m_support.tif'),('BANK','eel_mainstem_banks_v2_2m.tif'),('BANKSUPPORT','eel_mainstem_banks_v2_2m_support.tif'),('QUALITY','eel_mainstem_bed_quality_v3_1m.tif'),('ORIGINAL','eel_original_v2_comparison_cm.tif')]:html=html.replace('{{'+name+'}}',base64.b64encode((S/file).read_bytes()).decode())
html=html.replace('{{APP}}',(P/'app.js').read_text())
out=P/'eel_lidar_viewer.html';out.write_text(html)
assert out.stat().st_size < 100*1024**2, 'HTML exceeds GitHub file limit'
(P/'build_manifest.json').write_text(json.dumps({'html_bytes':out.stat().st_size,'rows':len(rows),'source':meta,'libraries':json.loads((P/'vendor/sources.json').read_text())},indent=2))
print(out,round(out.stat().st_size/1e6,1),'MB',len(rows),'intervals')
