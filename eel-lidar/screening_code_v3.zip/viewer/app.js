'use strict';
const DATA=JSON.parse(document.getElementById('river-data').textContent), rows=DATA.rows, $=id=>document.getElementById(id);
proj4.defs('EPSG:26910','+proj=utm +zone=10 +datum=NAD83 +units=m +no_defs');
const projection=proj4('EPSG:4326','EPSG:26910');
const toXY=ll=>projection.forward([ll.lng??ll[1],ll.lat??ll[0]]),toLL=xy=>{const a=projection.inverse(xy);return L.latLng(a[1],a[0]);};
const state={radius:1,stat:'median',selected:null,visible:[],mode:'auto',drawStart:null,section:null,autoCenter:null,normal:null,sectionToken:0,rasterToken:0,plotUpdating:false,ready:false,sectionSamples:[],lastProfileRange:[0,DATA.meta.route_km]};
const fmt=(v,n=3)=>v==null||!Number.isFinite(v)?'—':v.toFixed(n);
const radii=[1,2,5],traceColors=['#346eae','#178275','#b75073'];
$('sourceHash').textContent=DATA.meta.bed_sha256;
const map=L.map('map',{preferCanvas:true,zoomControl:true,zoomAnimation:false,fadeAnimation:false,markerZoomAnimation:false,minZoom:7,maxZoom:20,zoomSnap:.25});
map.createPane('bedPane');map.getPane('bedPane').style.zIndex=350;map.getPane('bedPane').style.pointerEvents='none';
map.createPane('sectionPane');map.getPane('sectionPane').style.zIndex=650;
const baseLayers={imagery:L.tileLayer('https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',{maxZoom:20,maxNativeZoom:19,attribution:'Tiles © Esri — Source: Esri, Maxar, Earthstar Geographics, and the GIS User Community'}),topo:L.tileLayer('https://basemap.nationalmap.gov/arcgis/rest/services/USGSTopo/MapServer/tile/{z}/{y}/{x}',{maxZoom:20,maxNativeZoom:16,attribution:'USGS The National Map'}),osm:L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:20,maxNativeZoom:19,attribution:'© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap contributors</a>'})};
baseLayers.imagery.addTo(map);let base='imagery',tileFailures=0;
Object.values(baseLayers).forEach(layer=>layer.on('tileerror',()=>{if(++tileFailures===4)$('dataStatus').textContent='Basemap tiles unavailable; embedded data remain usable. Try another basemap or None.';}));
L.control.scale({imperial:false,position:'bottomright'}).addTo(map);
const allBounds=L.latLngBounds(rows.flatMap(r=>r.ll.map(c=>[c[1],c[0]])));
const segments=[],segmentBounds=[];
function palette(v,lo=.02,hi=.20){const stops=[[68,1,84],[59,82,139],[33,145,140],[94,201,98],[253,231,37]];const t=Math.max(0,Math.min(1,(v-lo)/(hi-lo)))*4,i=Math.min(3,Math.floor(t)),f=t-i;return stops[i].map((c,j)=>Math.round(c*(1-f)+stops[i+1][j]*f));}
function colorMax(){return (state.radius===2?.4:.2)*(state.stat==='p90'?2:1);}
function lineColor(i){if(!rows[i].auto)return '#c88820';const v=rows[i][state.stat][state.radius];return v==null?'#939ca1':`rgb(${palette(v,.02,colorMax()).join(',')})`;}
const referenceGuide=L.polyline(DATA.reference.map(c=>[c[1],c[0]]),{color:'#d44436',weight:2,dashArray:'7 5',interactive:false});
$('referenceToggle').onchange=()=>{$('referenceToggle').checked?referenceGuide.addTo(map):map.removeLayer(referenceGuide);};
const guide=L.polyline(rows.flatMap(r=>r.ll.map(c=>[c[1],c[0]])),{color:'#fff',opacity:.7,weight:6,interactive:false}).addTo(map);
rows.forEach((r,i)=>{const lls=r.ll.map(c=>[c[1],c[0]]),line=L.polyline(lls,{color:lineColor(i),weight:3.2,opacity:1,dashArray:r.auto?null:'5 5',bubblingMouseEvents:false}).addTo(map);segments.push(line);segmentBounds.push(line.getBounds());line.on('mouseover',()=>hoverInterval(i));line.on('mouseout',()=>clearHover());line.on('click',e=>handleMapClick(e.latlng,i));});
const highlight=L.polyline([],{color:'#172d36',weight:7,opacity:.9,interactive:false}).addTo(map),focusHalo=L.polyline([],{color:'#fff',weight:3,opacity:1,interactive:false}).addTo(map);
const pointMarker=L.circleMarker([0,0],{radius:5,color:'#fff',weight:2,fillColor:'#172d36',fillOpacity:1,interactive:false});
const sectionLine=L.polyline([],{pane:'sectionPane',color:'#122d3a',weight:2.5,dashArray:'6 4',interactive:false}).addTo(map);
const sectionPoint=L.circleMarker([0,0],{pane:'sectionPane',radius:5,color:'#fff',weight:2,fillColor:'#e26c32',fillOpacity:1,interactive:false});
let endpoints=[],drawMarker=null;
function setHighlight(i){if(i==null){highlight.setLatLngs([]);focusHalo.setLatLngs([]);return;}const ll=segments[i].getLatLngs();highlight.setLatLngs(ll);focusHalo.setLatLngs(ll);highlight.bringToFront();focusHalo.bringToFront();}
function hoverInterval(i,fromPlot=false){setHighlight(i);pointMarker.setLatLng(rows[i].center).addTo(map);$('mapHover').textContent=` · km ${rows[i].km.toFixed(2)}–${(rows[i].km+rows[i].len/1000).toFixed(2)} · ${fmt(rows[i][state.stat][state.radius])} m`;
 if(!fromPlot&&$('profile')._fullLayout){const trs=$('profile').data;let ti=trs.findIndex(t=>t.name===`${radii[state.radius]} m radius`);if(ti<0)ti=0;const pi=trs[ti]?.customdata?.indexOf(i);if(pi>=0)Plotly.Fx.hover('profile',[{curveNumber:ti,pointNumber:pi}]);}}
function clearHover(){setHighlight(state.selected);map.removeLayer(pointMarker);$('mapHover').textContent='';Plotly.Fx.unhover('profile');}
function selectedShapes(){if(state.selected==null)return [];const r=rows[state.selected];return [{type:'rect',xref:'x',yref:'paper',x0:r.km,x1:r.km+r.len/1000,y0:0,y1:1,fillcolor:'rgba(207,112,42,0.13)',line:{color:'#bd692b',width:1},layer:'below'}];}
function qualityLabel(r){return r.auto?'Lidar-aligned':r.quality.replaceAll('_',' ').replaceAll(';','; ');}
const qcLabels=['No original supported bed','Coherent; below estimated surface','Shallow / surface unresolved','Above estimated surface','Surface check unavailable','Other unresolved support'];
function selectInterval(i){state.selected=i;const r=rows[i];setHighlight(i);$('intervalTag').textContent=`${radii[state.radius]} m radius`;$('selRoute').textContent=qualityLabel(r);$('selRefKm').textContent=fmt(r.refKm,2);$('selKm').textContent=`${r.km.toFixed(2)}–${(r.km+r.len/1000).toFixed(2)} km`;$('selMetricLabel').textContent=state.stat==='median'?'Median roughness':'90th percentile roughness';$('selRough').textContent=`${fmt(r[state.stat][state.radius])} m`;$('selCoverage').textContent=r.coverage[state.radius]==null?'—':`${(100*r.coverage[state.radius]).toFixed(1)}%`;$('selDensity').textContent=`${fmt(r.density,1)} pts/m²`;$('selArea').textContent=`${Math.round(r.area).toLocaleString()} m²`;$('gotoKm').value=r.km.toFixed(1);const qa=r.qc??[0,0,0,0,0],den=r.originalArea||1,pc=v=>(100*v/den).toFixed(1)+'%';$('qualitySummary').textContent=`Original bed support: ${Math.round(r.originalArea||0).toLocaleString()} m². Below surface: ${pc(qa[0])}; shallow / surface unresolved: ${pc(qa[1])}; surface check unavailable: ${pc(qa[3])}; above surface / other unresolved: ${pc(qa[2]+qa[4])}. These are fractions of original candidate-bed support.`;if($('profile')._fullLayout)Plotly.relayout('profile',{shapes:selectedShapes()});}
function intersectsLine(r,b){const w=b.getWest(),e=b.getEast(),s=b.getSouth(),n=b.getNorth();const inside=c=>c[0]>=w&&c[0]<=e&&c[1]>=s&&c[1]<=n;for(let j=1;j<r.ll.length;j++){const a=r.ll[j-1],z=r.ll[j];if(inside(a)||inside(z))return true;let t0=0,t1=1,dx=z[0]-a[0],dy=z[1]-a[1];let good=true;for(const [p,q]of[[-dx,a[0]-w],[dx,e-a[0]],[-dy,a[1]-s],[dy,n-a[1]]]){if(p===0){if(q<0){good=false;break;}}else{const t=q/p;if(p<0)t0=Math.max(t0,t);else t1=Math.min(t1,t);if(t0>t1){good=false;break;}}}if(good)return true;}return false;}
function visibleIndices(){const b=map.getBounds(),out=[];rows.forEach((r,i)=>{if(b.intersects(segmentBounds[i])&&intersectsLine(r,b))out.push(i);});return out;}
const plotConfig={responsive:true,displaylogo:false,scrollZoom:true,modeBarButtonsToRemove:['select2d','lasso2d','toggleSpikelines'],toImageButtonOptions:{format:'png',filename:'eel_roughness_profile',scale:2}};
const commonLayout={font:{family:'system-ui, sans-serif',size:11,color:'#253d47'},paper_bgcolor:'#fff',plot_bgcolor:'#fff',margin:{l:64,r:16,t:10,b:47},showlegend:false,hovermode:'closest',dragmode:'zoom'};
async function updateProfile(force=false){if(!force&&!$('followMap').checked)return;state.visible=visibleIndices();const ids=state.visible,visible=new Set(ids);let lo=ids.length?rows[ids[0]].km:state.lastProfileRange[0],hi=ids.length?rows[ids.at(-1)].km+rows[ids.at(-1)].len/1000:state.lastProfileRange[1];if(hi-lo<.15){const m=(lo+hi)/2;lo=Math.max(0,m-.075);hi=m+.075;}state.lastProfileRange=[lo,hi];const chosen=$('allRadii').checked?[0,1,2]:[state.radius],traces=chosen.map(k=>({x:rows.map(r=>r.km+r.len/2000),y:rows.map((r,i)=>visible.has(i)&&r.auto?r[state.stat][k]:null),customdata:rows.map((r,i)=>i),mode:hi-lo<4?'lines+markers':'lines',type:'scatter',connectgaps:false,line:{color:traceColors[k],width:k===state.radius?1.9:1.1},marker:{size:4},name:`${radii[k]} m radius`,hovertemplate:`km %{x:.2f}<br>${state.stat==='median'?'Median':'90th percentile'} RMS: %{y:.4f} m<br>${radii[k]} m radius<extra></extra>`}));
 const vals=traces.flatMap(t=>t.y).filter(v=>v!=null),max=vals.length?Math.max(...vals):.1;state.plotUpdating=true;try{await Plotly.react('profile',traces,{...commonLayout,shapes:selectedShapes(),xaxis:{title:{text:'Distance downstream from upstream survey edge (km)',standoff:10},range:[lo,hi],zeroline:false,showgrid:true,gridcolor:'#e8edef',tickformat:hi-lo<2?'.2f':'.1f',fixedrange:false},yaxis:{title:{text:'Roughness RMS (m)',standoff:8},range:[0,Math.max(.015,max*1.13)],rangemode:'tozero',gridcolor:'#e8edef',zerolinecolor:'#c6d0d4'},showlegend:chosen.length>1,legend:{orientation:'h',x:1,xanchor:'right',y:1.04,yanchor:'bottom',font:{size:10}},margin:{...commonLayout.margin,t:chosen.length>1?30:10},annotations:ids.length?[]:[{text:'No mainstem intervals in this map view',xref:'paper',yref:'paper',x:.5,y:.5,showarrow:false,font:{color:'#60727a',size:13}}]},plotConfig);}finally{state.plotUpdating=false;}
 await adaptPlot('profile');$('profileExtent').textContent=ids.length?`km ${lo.toFixed(2)}–${hi.toFixed(2)} · ${ids.length} intervals (${ids.filter(i=>!rows[i].auto).length} flagged) · 100 m summaries`:'No mainstem intervals in this map view';$('mapExtent').textContent=ids.length?`River km ${lo.toFixed(1)}–${hi.toFixed(1)}`:'Outside the mapped mainstem';}
function nearestRiver(q){let best={distance:Infinity};rows.forEach((r,i)=>{let along=0;for(let j=1;j<r.xy.length;j++){const a=r.xy[j-1],b=r.xy[j],dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy);if(!len)continue;const t=Math.max(0,Math.min(1,((q[0]-a[0])*dx+(q[1]-a[1])*dy)/(len*len))),p=[a[0]+t*dx,a[1]+t*dy],d=Math.hypot(q[0]-p[0],q[1]-p[1]);if(d<best.distance)best={distance:d,i,point:p,tangent:[dx/len,dy/len],km:r.km+(along+t*len)/1000};along+=len;}});return best;}
function routePointAt(km){
 km=Math.max(0,Math.min(DATA.meta.route_km,km));const i=Math.min(rows.length-1,Math.floor(km*10)),r=rows[i];let distance=Math.max(0,(km-r.km)*1000);
 for(let j=1;j<r.xy.length;j++){const a=r.xy[j-1],b=r.xy[j],len=Math.hypot(b[0]-a[0],b[1]-a[1]);if(distance<=len)return[a[0]+(b[0]-a[0])*distance/len,a[1]+(b[1]-a[1])*distance/len];distance-=len;}return r.xy.at(-1);
}
function routeTangent(km){const a=routePointAt(km-.02),b=routePointAt(km+.02),d=Math.hypot(b[0]-a[0],b[1]-a[1]);return d?[(b[0]-a[0])/d,(b[1]-a[1])/d]:[1,0];}
function handleMapClick(ll,knownIndex){if(state.mode==='draw'){if(!state.drawStart){state.drawStart=toXY(ll);drawMarker=L.circleMarker(ll,{radius:5,color:'#172d36',fillOpacity:1}).addTo(map);$('sectionHelp').textContent='Click endpoint B. Escape cancels.';}else{const a=state.drawStart,b=toXY(ll);state.drawStart=null;if(drawMarker)map.removeLayer(drawMarker);state.autoCenter=null;setSection(a,b);$('sectionHelp').textContent='Drag A or B to adjust. Click two new endpoints to draw another section.';}return;}
 const q=toXY(ll),near=nearestRiver(q);if(near.distance>150){$('sectionHelp').textContent='Click within 150 m of the mapped mainstem, or use Draw A–B for a custom section.';return;}selectInterval(near.i);if(!rows[near.i].auto){$('clearSection').click();$('sectionHelp').textContent='Automatic section unavailable: '+qualityLabel(rows[near.i])+'. Use Draw A–B to inspect the lidar directly.';$('sectionStatus').textContent='Route uncertain here; no automatic section placed.';return;}state.autoCenter=near.point;$('sectionHelp').textContent=`Section centered on the lidar-aligned route (${near.distance.toFixed(1)} m from click). Drag A or B for a manual adjustment.`;$('sectionWidth').disabled=false;$('rotation').disabled=false;const tangent=routeTangent(near.km);state.normal=[-tangent[1],tangent[0]];$('rotation').value=0;$('rotationValue').textContent='0°';if(map.getZoom()<13)map.setView(toLL(near.point),15);makeAutoSection();}
function makeAutoSection(){if(!state.autoCenter)return;const a=Number($('rotation').value)*Math.PI/180,n=state.normal,v=[n[0]*Math.cos(a)-n[1]*Math.sin(a),n[0]*Math.sin(a)+n[1]*Math.cos(a)],half=Number($('sectionWidth').value)/2,c=state.autoCenter;setSection([c[0]-v[0]*half,c[1]-v[1]*half],[c[0]+v[0]*half,c[1]+v[1]*half]);}
function setSection(a,b){const length=Math.hypot(b[0]-a[0],b[1]-a[1]);if(length<2||length>2000){$('sectionStatus').textContent='Choose a section between 2 and 2,000 m long.';return;}state.section={a,b,length};sectionLine.setLatLngs([toLL(a),toLL(b)]);endpoints.forEach(m=>map.removeLayer(m));endpoints=[a,b].map((p,i)=>{const m=L.marker(toLL(p),{pane:'sectionPane',draggable:true,icon:L.divIcon({className:'',html:`<div class="endpoint">${i?'B':'A'}</div>`,iconSize:[22,22],iconAnchor:[11,11]})}).addTo(map);m.on('drag',()=>{sectionLine.setLatLngs(endpoints.map(x=>x.getLatLng()));});m.on('dragend',()=>{state.autoCenter=null;$('sectionWidth').disabled=true;$('rotation').disabled=true;setSection(toXY(endpoints[0].getLatLng()),toXY(endpoints[1].getLatLng()));});return m;});const near=nearestRiver([(a[0]+b[0])/2,(a[1]+b[1])/2]);selectInterval(near.i);drawSectionProfile();}
let bedTiff,supportTiff,bedImage,supportImage,bankImage,bankSupportImage,qualityImage,originalImage,images=[],bankImages=[],qualityImages=[],originalImages=[];
function decodeEmbedded(id){const el=$(id),s=el.textContent.trim(),binary=atob(s),bytes=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);el.remove();return bytes.buffer;}
function patchSparse(image){const original=image.getTileOrStrip.bind(image),fd=image.fileDirectory,cache=new Map(),limit=128;const empty=image.getSampleFormat()===3?new Float32Array(image.getTileWidth()*image.getTileHeight()).fill(image.getGDALNoData()??-9999):(image.getBitsPerSample()===16?new Uint16Array(image.getTileWidth()*image.getTileHeight()):new Uint8Array(image.getTileWidth()*image.getTileHeight()));
 image.getTileOrStrip=async function(x,y,sample,decoder,signal){const index=y*Math.ceil(image.getWidth()/image.getTileWidth())+x;if(fd.TileByteCounts[index]===0)return{x,y,sample,data:empty.buffer};const key=index;if(cache.has(key)){const value=cache.get(key);cache.delete(key);cache.set(key,value);return value;}const promise=original(x,y,sample,decoder,signal);cache.set(key,promise);if(cache.size>limit)cache.delete(cache.keys().next().value);try{return await promise;}catch(e){cache.delete(key);throw e;}};return image;}
async function initRasters(){try{bedTiff=await GeoTIFF.fromArrayBuffer(decodeEmbedded('bathy-bytes'));supportTiff=await GeoTIFF.fromArrayBuffer(decodeEmbedded('support-bytes'));for(let i=0;i<await bedTiff.getImageCount();i++)images.push(patchSparse(await bedTiff.getImage(i)));bedImage=images[0];supportImage=patchSparse(await supportTiff.getImage());const bankTiff=await GeoTIFF.fromArrayBuffer(decodeEmbedded('bank-bytes'));for(let i=0;i<await bankTiff.getImageCount();i++)bankImages.push(patchSparse(await bankTiff.getImage(i)));bankImage=bankImages[0];bankSupportImage=patchSparse(await (await GeoTIFF.fromArrayBuffer(decodeEmbedded('bank-support-bytes'))).getImage());const qt=await GeoTIFF.fromArrayBuffer(decodeEmbedded('quality-bytes')),ot=await GeoTIFF.fromArrayBuffer(decodeEmbedded('original-bytes'));for(let i=0;i<await qt.getImageCount();i++)qualityImages.push(patchSparse(await qt.getImage(i)));for(let i=0;i<await ot.getImageCount();i++)originalImages.push(patchSparse(await ot.getImage(i)));qualityImage=qualityImages[0];originalImage=originalImages[0];state.ready=true;$('dataStatus').classList.remove('loading');$('dataStatus').textContent='Return screen v3 · 1 m bed · 2 m banks · original comparison available';renderBed();if(state.section)drawSectionProfile();}catch(e){$('dataStatus').textContent=`Bathymetry could not load: ${e.message}`;console.error(e);}}
async function sampleRaster(image,points){
 const [left,bottom,right,top]=DATA.meta.raster_bounds,w=image.getWidth(),h=image.getHeight(),rx=(right-left)/w,ry=(top-bottom)/h;
 const cols=points.map(p=>Math.floor((p[0]-left)/rx)),rs=points.map(p=>Math.floor((top-p[1])/ry));
 const x0=Math.max(0,Math.min(...cols)),x1=Math.min(w,Math.max(...cols)+1),y0=Math.max(0,Math.min(...rs)),y1=Math.min(h,Math.max(...rs)+1);
 let values=null;if(x1>x0&&y1>y0)values=await image.readRasters({window:[x0,y0,x1,y1],samples:[0],interleave:true});
 return points.map((p,i)=>{const c=cols[i]-x0,r=rs[i]-y0;if(!values||c<0||r<0||c>=x1-x0||r>=y1-y0)return null;const v=values[r*(x1-x0)+c];return v===image.getGDALNoData()||!Number.isFinite(v)?null:v;});
}
async function sampleSection(a,b){
 const len=Math.hypot(b[0]-a[0],b[1]-a[1]),distances=Array.from({length:Math.floor(len)+1},(_,i)=>i);if(len-distances.at(-1)>1e-6)distances.push(len);
 const points=distances.map(d=>[a[0]+(b[0]-a[0])*d/len,a[1]+(b[1]-a[1])*d/len]);
 const [z,s,g,gs,qc,orig]=await Promise.all([sampleRaster(bedImage,points),sampleRaster(supportImage,points),sampleRaster(bankImage,points),sampleRaster(bankSupportImage,points),sampleRaster(qualityImage,points),sampleRaster(originalImage,points)]);
 return points.map((p,i)=>{const ll=projection.inverse(p);return{distance:distances[i],x:p[0],y:p[1],lon:ll[0],lat:ll[1],z:z[i],support:z[i]==null?0:s[i],ground:[2,3,5].includes(qc[i])?null:g[i],groundSupport:[2,3,5].includes(qc[i])||g[i]==null?0:gs[i],qc:qc[i]??0,original:orig[i]==null?null:orig[i]/100-1};});
}
// Only join transitions between different sources; never bridge an internal bed gap.
function bankBedLinks(samples,maxGap=30){
 const supported=samples.filter(s=>s.z!=null||s.ground!=null),links=[];
 for(let i=1;i<supported.length;i++){const a=supported[i-1],b=supported[i];if((a.z!=null)!==(b.z!=null)&&b.distance-a.distance<=maxGap&&!samples.some(s=>s.distance>a.distance&&s.distance<b.distance&&[2,3,5].includes(s.qc)))links.push([a,b]);}
 return links;
}
async function drawSectionProfile(){if(!state.section)return;const token=++state.sectionToken;if(!state.ready){$('sectionStatus').textContent='Loading embedded TIFF; the section will appear when ready.';return;}$('sectionStatus').textContent='Sampling bed and ground rasters…';try{const samples=await sampleSection(state.section.a,state.section.b);if(token!==state.sectionToken)return;state.sectionSamples=samples;const showBanks=$('showBanks').checked,displayZ=s=>s.z??(showBanks?s.ground:null)??($('originalToggle').checked?s.original:null),valid=samples.filter(s=>displayZ(s)!==null),bedValid=samples.filter(s=>s.z!==null||($('originalToggle').checked&&s.original!==null)),focus=$('fitSection').checked&&showBanks&&bedValid.length?valid.filter(s=>s.distance>=bedValid[0].distance-30&&s.distance<=bedValid.at(-1).distance+30&&displayZ(s)<=Math.max(...bedValid.map(p=>p.z??p.original))+5):valid,z=($('fitSection').checked?focus:valid).map(displayZ).concat($('originalToggle').checked?($('fitSection').checked?focus:valid).map(s=>s.original).filter(v=>v!==null):[]),min=z.length?Math.min(...z):0,max=z.length?Math.max(...z):1,pad=Math.max(.15,(max-min)*.14);const traces=[{x:samples.map(s=>s.distance),y:samples.map(s=>s.z),customdata:samples.map((_,i)=>i),type:'scatter',mode:'lines',connectgaps:false,line:{color:'#476270',width:1.2},hoverinfo:'skip',showlegend:false},...[[1,'Bed','#236fa1'],[2,'Bed interp.','#c96d24']].map(([code,name,color])=>({x:samples.map(s=>s.support===code?s.distance:null),y:samples.map(s=>s.support===code?s.z:null),customdata:samples.map((_,i)=>i),text:samples.map(s=>qcLabels[s.qc]),type:'scatter',mode:'markers',name,marker:{color:samples.map(s=>s.qc===4?'#845890':color),size:4},hovertemplate:`%{x:.1f} m from A<br>%{y:.3f} m elevation<br>${name} cell<br>%{text}<extra></extra>`}))];if($('originalToggle').checked)traces.push({x:samples.map(s=>s.distance),y:samples.map(s=>s.z==null||Math.abs(s.original-s.z)>.01?s.original:null),customdata:samples.map((_,i)=>i),text:samples.map(s=>qcLabels[s.qc]),type:'scatter',mode:'markers',name:'Original v2 comparison',marker:{color:'#6d7075',symbol:'x',size:4},hovertemplate:'%{x:.1f} m from A<br>%{y:.2f} m original v2<br>%{text}<extra></extra>'});$('comparisonKey').hidden=!$('originalToggle').checked;const links=showBanks&&$('connectBanks').checked?bankBedLinks(samples):[];if(links.length)traces.push({x:links.flatMap(pair=>[...pair.map(s=>s.distance),null]),y:links.flatMap(pair=>[...pair.map(displayZ),null]),mode:'lines',type:'scatter',connectgaps:false,line:{color:'#6d7377',width:1.5,dash:'dash'},name:'Bank–bed join',hoverinfo:'skip'});$('groundKey').hidden=!showBanks;$('joinKey').hidden=!links.length;if(showBanks)traces.push({x:samples.map(s=>s.distance),y:samples.map(s=>s.z==null?s.ground:null),customdata:samples.map((_,i)=>i),type:'scatter',mode:'lines+markers',connectgaps:false,name:'Ground (2 m)',line:{color:'#795537',width:1.6},marker:{size:3},hovertemplate:'%{x:.1f} m from A<br>%{y:.3f} m ground elevation<br>Class 2 terrain, 2 m cells<extra></extra>'});await Plotly.react('sectionPlot',traces,{...commonLayout,margin:{l:57,r:8,t:10,b:43},xaxis:{title:{text:'Distance from A (m)',standoff:5},range:$('fitSection').checked&&focus.length?[Math.max(0,focus[0].distance-5),Math.min(state.section.length,focus.at(-1).distance+5)]:[0,state.section.length],gridcolor:'#e8edef',zeroline:false},yaxis:{title:{text:'Elevation (m)',standoff:4},range:[min-pad,max+pad],tickformat:'.2f',gridcolor:'#e8edef',zeroline:false},showlegend:false,annotations:valid.length?[]:[{text:'No supported elevation cells on this section',xref:'paper',yref:'paper',x:.5,y:.5,showarrow:false,font:{size:11}}]}, {...plotConfig,modeBarButtonsToRemove:['select2d','lasso2d','toggleSpikelines','autoScale2d'],toImageButtonOptions:{format:'png',filename:'eel_bed_cross_section',scale:2}});$('sectionStatus').textContent=`${samples.filter(s=>s.z!==null).length} bed${showBanks?` + ${samples.filter(s=>s.z==null&&s.ground!==null).length} ground`:''} / ${samples.length} positions · ${state.section.length.toFixed(1)} m section. ${samples.filter(s=>[2,3,5].includes(s.qc)).length} unresolved; ${samples.filter(s=>s.qc===4).length} without surface check. ${links.length?`${links.length} dashed bank–bed joins (≤30 m); other gaps are NoData.`:'Gaps are NoData.'}`;await adaptPlot('sectionPlot');$('sectionCoords').textContent=`A ${state.section.a.map(v=>v.toFixed(1)).join(', ')}\nB ${state.section.b.map(v=>v.toFixed(1)).join(', ')} · UTM 10N`;$('exportSection').disabled=false;}catch(e){$('sectionStatus').textContent=`Section sampling failed: ${e.message}`;console.error(e);}}
const canvas=document.createElement('canvas');canvas.style.position='absolute';canvas.style.pointerEvents='none';map.getPane('bedPane').appendChild(canvas);
function hideBed(){canvas.style.display='none';$('bedLegend').hidden=true;$('bankLegend').hidden=true;}
// Surface normal dotted with a unit light vector: NW azimuth 315°, altitude 45°.
function hillshade(eastSlope,northSlope){return Math.max(0,(-eastSlope*-.5-northSlope*.5+Math.SQRT1_2)/Math.hypot(eastSlope,northSlope,1));}
function shadeCell(values,width,height,x,y,rx,ry,nodata=-9999){
 if(x<1||y<1||x>=width-1||y>=height-1)return null;
 const c=values[y*width+x],w=values[y*width+x-1],e=values[y*width+x+1],n=values[(y-1)*width+x],s=values[(y+1)*width+x];
 if([c,w,e,n,s].some(v=>v===nodata||!Number.isFinite(v)))return null;
 return hillshade((e-w)/(2*rx),(n-s)/(2*ry));
}
function bankColor(t){t=clamp(t,0,1);const a=[238,229,207],b=[103,72,47];return a.map((v,i)=>Math.round(v+(b[i]-v)*t));}
// Map-only styling. Numerical section sampling and source rasters are unchanged.
function bedPalette(t){
 const stops=[[18,45,82],[30,103,155],[74,172,193],[153,215,211],[239,246,221]];
 t=clamp(t,0,1)*4;const i=Math.min(3,Math.floor(t)),f=t-i;
 return stops[i].map((v,j)=>Math.round(v*(1-f)+stops[i+1][j]*f));
}
function bedDisplayRange(values,nodata){
 const valid=[];for(const v of values)if(v!==nodata&&Number.isFinite(v))valid.push(v);
 if(!valid.length)return null;valid.sort((a,b)=>a-b);
 const q=p=>{const x=(valid.length-1)*p,i=Math.floor(x);return valid[i]+(valid[Math.min(i+1,valid.length-1)]-valid[i])*(x-i);};
 const lo=q(.02),hi=Math.max(lo+.1,q(.98));return[lo,hi];
}
function contourSpacing(zoom,choice='auto'){return choice==='auto'?(zoom>=16?1:zoom>=15?2:zoom>=14?5:10):Number(choice);}
function contourSegments(values,width,height,interval,nodata=-9999){
 const out=[];
 for(let y=0;y<height-1;y++)for(let x=0;x<width-1;x++){
  const v=[values[y*width+x],values[y*width+x+1],values[(y+1)*width+x+1],values[(y+1)*width+x]];
  // Every corner must be supported: no contours across a NoData gap or between separate sources.
  if(v.some(z=>z===nodata||!Number.isFinite(z)))continue;
  const lo=Math.min(...v),hi=Math.max(...v),xy=[[x,y],[x+1,y],[x+1,y+1],[x,y+1]];
  for(let k=Math.floor(lo/interval)+1;k*interval<=hi;k++){
   const level=k*interval,hits=[];
   for(let e=0;e<4;e++){
    const j=(e+1)%4;if((v[e]<level)===(v[j]<level))continue;
    const t=(level-v[e])/(v[j]-v[e]);hits.push({edge:e,point:[xy[e][0]+t*(xy[j][0]-xy[e][0]),xy[e][1]+t*(xy[j][1]-xy[e][1])]});
   }
   const add=(a,b)=>{if(Math.hypot(a[0]-b[0],a[1]-b[1])>1e-9)out.push({level,major:k%5===0,points:[a,b]});};
   if(hits.length===2)add(hits[0].point,hits[1].point);
   else if(hits.length===4){
    // Bilinear asymptotic decider for saddle cells, preserving the contour topology.
    const d=(v[0]-level)*(v[2]-level)-(v[1]-level)*(v[3]-level),pairs=d>=0?[[0,1],[2,3]]:[[0,3],[1,2]];
    for(const [a,b] of pairs)add(hits[a].point,hits[b].point);
   }
  }
 }
 return out;
}
function drawContours(ctx,layer,interval,sx,sy){
 const a=layer,segments=contourSegments(a.values,a.width,a.height,interval,a.nodata),paths=[[],[]];
 for(const s of segments){
  const p=s.points.map(([x,y])=>{const q=map.latLngToContainerPoint(toLL([a.left+(a.x0+x+.5)*a.rx,a.top-(a.y0+y+.5)*a.ry]));return[q.x/sx,q.y/sy];});
  if(p.every(q=>q[0]<-5)||p.every(q=>q[1]<-5)||p.every(q=>q[0]>ctx.canvas.width+5)||p.every(q=>q[1]>ctx.canvas.height+5))continue;
  paths[s.major?1:0].push({points:p,level:s.level});
 }
 ctx.save();ctx.lineCap='round';ctx.lineJoin='round';
 for(let major=0;major<2;major++){
  ctx.beginPath();for(const s of paths[major]){ctx.moveTo(...s.points[0]);ctx.lineTo(...s.points[1]);}
  if(a.kind==='bed'){ctx.strokeStyle='rgba(240,250,250,.4)';ctx.lineWidth=major?2:1.5;ctx.stroke();}
  ctx.strokeStyle=a.kind==='bed'?'rgba(15,44,66,.72)':'rgba(52,59,52,.46)';ctx.lineWidth=major?1:.55;ctx.stroke();
 }
 // Label only index contours, sparsely; label values are absolute source-datum elevations.
 const labels=[];ctx.font='10px system-ui';ctx.textAlign='center';ctx.textBaseline='middle';
 for(const s of paths[1]){
  const p=[(s.points[0][0]+s.points[1][0])/2,(s.points[0][1]+s.points[1][1])/2];
  if(p[0]<30||p[0]>ctx.canvas.width-30||p[1]<25||p[1]>ctx.canvas.height-25||labels.some(q=>Math.hypot(q[0]-p[0],q[1]-p[1])<110))continue;
  const text=s.level.toFixed(interval<1?1:0);ctx.strokeStyle='rgba(255,255,255,.9)';ctx.lineWidth=3;ctx.strokeText(text,...p);ctx.fillStyle='#243943';ctx.fillText(text,...p);labels.push(p);if(labels.length>=10)break;
 }
 ctx.restore();return paths[0].length+paths[1].length;
}

async function renderBed(){
 const token=++state.rasterToken,bedColor=$('bedToggle').checked,bankColorOn=$('bankToggle').checked,bedShade=$('bedShade').checked,bankShade=$('bankShade').checked,contours=$('contourToggle').checked,qualityOn=$('qualityToggle').checked,originalOn=$('originalToggle').checked;$('qualityLegend').hidden=!qualityOn;
 if(!state.ready||map.getZoom()<13||!(bedColor||bankColorOn||bedShade||bankShade||qualityOn||originalOn)){hideBed();$('mapNote').textContent=map.getZoom()<13?'Zoom in to view lidar rasters.':'Lidar rasters are off. Sections still sample the TIFFs.';return;}
 const size=map.getSize(),cw=Math.min(size.x,1400),ch=Math.round(size.y*cw/size.x),sx=size.x/cw,sy=size.y/ch,step=24,nx=Math.ceil(cw/step),ny=Math.ceil(ch/step),mesh=[];
 let xmin=Infinity,ymin=Infinity,xmax=-Infinity,ymax=-Infinity;
 for(let gy=0;gy<=ny;gy++){const row=[];for(let gx=0;gx<=nx;gx++){const q=toXY(map.containerPointToLatLng([Math.min(gx*step,cw)*sx,Math.min(gy*step,ch)*sy]));row.push(q);xmin=Math.min(xmin,q[0]);xmax=Math.max(xmax,q[0]);ymin=Math.min(ymin,q[1]);ymax=Math.max(ymax,q[1]);}mesh.push(row);}
 const mpp=(xmax-xmin)/cw,opacity=Number($('rasterOpacity').value)/100;
 async function readLayer(imList,colorOn,shadeOn,kind){
  if(!colorOn&&!shadeOn)return null;let image=imList[0];const [left,bottom,right,top]=DATA.meta.raster_bounds;
  for(const im of imList)if((right-left)/im.getWidth()<=mpp*1.6)image=im;
  const rx=(right-left)/image.getWidth(),ry=(top-bottom)/image.getHeight(),x0=Math.max(0,Math.floor((xmin-left)/rx)-1),x1=Math.min(image.getWidth(),Math.ceil((xmax-left)/rx)+1),y0=Math.max(0,Math.floor((top-ymax)/ry)-1),y1=Math.min(image.getHeight(),Math.ceil((top-ymin)/ry)+1);
  if(x1<=x0||y1<=y0)return null;
  let values=await image.readRasters({window:[x0,y0,x1,y1],samples:[0],interleave:true}),nodata=image.getGDALNoData();if(kind==='original')values=Float32Array.from(values,v=>v===0?-9999:v/100-1);const actualNoData=kind==='original'?-9999:nodata;let lo=Infinity,hi=-Infinity;
  for(const v of values)if(v!==actualNoData&&Number.isFinite(v)){lo=Math.min(lo,v);hi=Math.max(hi,v);}
  if(!Number.isFinite(lo))return null;
  if(kind==='bed'){[lo,hi]=bedDisplayRange(values,nodata);}
  return{values,rx,ry,x0,y0,width:x1-x0,height:y1-y0,left,top,lo,hi:Math.max(lo+.1,hi),nodata:actualNoData,colorOn,shadeOn,kind};
 }
 $('mapNote').textContent='Reading lidar rasters…';
 try{
  const layers=await Promise.all([readLayer(bankImages,bankColorOn,bankShade,'bank'),readLayer(originalImages,originalOn,false,'original'),readLayer(images,bedColor,bedShade,'bed'),readLayer(qualityImages,qualityOn,false,'quality')]);if(token!==state.rasterToken)return;
  canvas.width=cw;canvas.height=ch;canvas.style.width=size.x+'px';canvas.style.height=size.y+'px';canvas.style.opacity=opacity;L.DomUtil.setPosition(canvas,map.containerPointToLayerPoint([0,0]));
  const ctx=canvas.getContext('2d');ctx.clearRect(0,0,cw,ch);let pixels=0;
  for(const layer of layers){if(!layer)continue;const img=ctx.createImageData(cw,ch),a=layer,lut=Array.from({length:256},(_,i)=>a.kind==='bank'?bankColor(i/255):a.kind==='original'?[135,140,144]:bedPalette(i/255));let layerPixels=0;
   for(let py=0;py<ch;py++){const gy=Math.min(ny-1,Math.floor(py/step)),fy=(py-gy*step)/(Math.min((gy+1)*step,ch)-gy*step);for(let px=0;px<cw;px++){const gx=Math.min(nx-1,Math.floor(px/step)),fx=(px-gx*step)/(Math.min((gx+1)*step,cw)-gx*step),p=mesh[gy][gx],q=mesh[gy][gx+1],r=mesh[gy+1][gx],s=mesh[gy+1][gx+1],ux=(p[0]*(1-fx)+q[0]*fx)*(1-fy)+(r[0]*(1-fx)+s[0]*fx)*fy,uy=(p[1]*(1-fx)+q[1]*fx)*(1-fy)+(r[1]*(1-fx)+s[1]*fx)*fy,ix=Math.floor((ux-a.left)/a.rx)-a.x0,iy=Math.floor((a.top-uy)/a.ry)-a.y0;
    if(ix<0||iy<0||ix>=a.width||iy>=a.height)continue;const v=a.values[iy*a.width+ix];if(v===a.nodata||!Number.isFinite(v))continue;
    if(a.kind==='quality'){if(v===1||v===0||((px+py)%10)>2)continue;const rgb=v===2?[189,118,21]:v===4?[121,85,143]:[182,75,84],k=(py*cw+px)*4;img.data.set([...rgb,200],k);layerPixels++;continue;}const shade=a.shadeOn?shadeCell(a.values,a.width,a.height,ix,iy,a.rx,a.ry,a.nodata):null;if(!a.colorOn&&shade===null)continue;
    let rgb=a.colorOn?lut[clamp(Math.round((v-a.lo)/(a.hi-a.lo)*255),0,255)]:[255,255,255];if(shade!==null)rgb=rgb.map(c=>Math.round(c*(a.colorOn?(a.kind==='bed'?.68+.32*shade:.35+.65*shade):shade)));
    const k=(py*cw+px)*4;img.data[k]=rgb[0];img.data[k+1]=rgb[1];img.data[k+2]=rgb[2];img.data[k+3]=a.kind==='original'?170:255;layerPixels++;
   }}
   // Compose bed above banks while preserving transparent pixels in each layer.
   const tmp=document.createElement('canvas');tmp.width=cw;tmp.height=ch;const tc=tmp.getContext('2d');tc.putImageData(img,0,0);
   if(contours&&['bed','bank'].includes(a.kind))drawContours(tc,a,contourSpacing(map.getZoom(),$('contourInterval').value),sx,sy);
   ctx.drawImage(tmp,0,0);pixels+=layerPixels;
  }
  for(const kind of ['bed','bank']){const a=layers.find(l=>l?.kind===kind);$(kind+'Legend').hidden=!a?.colorOn;if(a){$(kind+'Min').textContent=(kind==='bed'?'≤ ':'')+a.lo.toFixed(2);$(kind+'Max').textContent=(kind==='bed'?'≥ ':'')+a.hi.toFixed(2);}}
  canvas.style.display=pixels?'block':'none';$('mapNote').textContent=pixels?`Lidar: ${layers.filter(a=>a&&['bed','bank'].includes(a.kind)).map(a=>`${a.kind==='bed'?'screened bed':'banks'} ${a.rx.toFixed(0)} m`).join(' · ')}${bedShade||bankShade?' · light NW, 45°':''}${contours?' · contours '+contourSpacing(map.getZoom(),$('contourInterval').value)+' m':''}`:'No supported cells for the enabled lidar layers here.';
 }catch(e){if(token===state.rasterToken){hideBed();$('mapNote').textContent='Lidar preview unavailable: '+e.message;}console.error(e);}
}
function updateStyles(){segments.forEach((l,i)=>l.setStyle({color:lineColor(i),weight:map.getZoom()>=15?2:3.2,opacity:map.getZoom()>=15?.7:1}));guide.setStyle({weight:map.getZoom()>=15?3:6,opacity:map.getZoom()>=15?.3:.7});$('routeLegendTitle').textContent=`${state.stat==='median'?'Median':'90th percentile'} roughness · ${radii[state.radius]} m radius (m)`;const tick=$('routeLegendTitle').parentElement.querySelector('.legend-ticks').children;tick[0].textContent='0.02';tick[1].textContent=((.02+colorMax())/2).toFixed(2);tick[2].textContent=colorMax().toFixed(2)+'+';if(state.selected!=null)selectInterval(state.selected);}
function downloadCSV(name,header,data){const escape=v=>v==null?'':String(v).includes(',')?`"${String(v).replaceAll('"','""')}"`:String(v);const text=[header,...data].map(r=>r.map(escape).join(',')).join('\r\n');const url=URL.createObjectURL(new Blob([text],{type:'text/csv;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
$('exportSection').onclick=()=>downloadCSV(`eel_section_km${rows[state.selected].km.toFixed(2)}.csv`,['distance_from_A_m','easting_NAD83_UTM10N_m','northing_NAD83_UTM10N_m','longitude','latitude','bed_elevation_m','support_1_sampled_2_interpolated_0_nodata','ground_elevation_2m_m','ground_support_1_sampled_2_interpolated_0_nodata','bed_quality_code','bed_quality_label','original_v2_elevation_comparison_rounded_cm_m'],state.sectionSamples.map(s=>[s.distance,s.x,s.y,s.lon,s.lat,s.z,s.support,s.ground,s.groundSupport,s.qc,qcLabels[s.qc],s.original]));
$('exportReach').onclick=()=>{const ids=visibleIndices();downloadCSV('eel_roughness_visible_intervals.csv',['route_version','route_quality','automatic_section_supported','original_guide_km','river_km_start','interval_length_m','median_r1_m','median_r2_m','median_r5_m','p90_r1_m','p90_r2_m','p90_r5_m','coverage_r1','coverage_r2','coverage_r5','mean_bed_returns_per_m2','supported_bed_area_m2','original_bed_area_m2','below_surface_area_m2','shallow_surface_unresolved_area_m2','above_surface_area_m2','surface_check_unavailable_area_m2','other_unresolved_area_m2'],ids.map(i=>{const r=rows[i];return[DATA.meta.route_version,r.quality,r.auto,r.refKm,r.km,r.len,...r.median,...r.p90,...r.coverage,r.density,r.area,r.originalArea,...r.qc];}));};
$('originalToggle').onchange=()=>{renderBed();if(state.section)drawSectionProfile();};
$('basemap').onchange=()=>{if(baseLayers[base])map.removeLayer(baseLayers[base]);base=$('basemap').value;tileFailures=0;if(baseLayers[base])baseLayers[base].addTo(map);};
$('radius').onchange=()=>{state.radius=+$('radius').value;updateStyles();updateProfile(true);};$('stat').onchange=()=>{state.stat=$('stat').value;updateStyles();updateProfile(true);};$('allRadii').onchange=()=>updateProfile(true);$('followMap').onchange=()=>{if($('followMap').checked)updateProfile(true);};for(const id of ['bedToggle','bankToggle','bedShade','bankShade','contourToggle','contourInterval','qualityToggle'])$(id).onchange=renderBed;$('rasterOpacity').oninput=()=>{$('opacityValue').textContent=$('rasterOpacity').value+'%';canvas.style.opacity=Number($('rasterOpacity').value)/100;};$('roughToggle').onchange=()=>{const on=$('roughToggle').checked;for(const layer of [guide,...segments])on?layer.addTo(map):map.removeLayer(layer);$('routeLegendTitle').hidden=!on;$('routeLegendTitle').nextElementSibling.hidden=!on;$('routeLegendTitle').nextElementSibling.nextElementSibling.hidden=!on;$('roughNote').hidden=!on;};
$('fullBtn').onclick=()=>{$('followMap').checked=true;map.fitBounds(allBounds,{padding:[25,25]});};$('angeloBtn').onclick=()=>{map.setView(toLL([445650,4398400]),15);};$('gotoBtn').onclick=()=>{const km=Math.max(0,Math.min(DATA.meta.route_km,Number($('gotoKm').value)||0)),i=Math.min(rows.length-1,Math.floor(km*10));selectInterval(i);map.setView(rows[i].center,15);if(state.mode==='auto')handleMapClick(L.latLng(rows[i].center),i);};$('gotoKm').onkeydown=e=>{if(e.key==='Enter')$('gotoBtn').click();};
function setMode(mode){state.mode=mode;$('sectionWidth').disabled=mode==='draw'||!state.autoCenter;$('rotation').disabled=mode==='draw'||!state.autoCenter;state.drawStart=null;if(drawMarker)map.removeLayer(drawMarker);$('autoBtn').classList.toggle('active',mode==='auto');$('drawBtn').classList.toggle('active',mode==='draw');$('map').classList.toggle('draw-cursor',mode==='draw');$('sectionHelp').textContent=mode==='draw'?'Click endpoint A, then endpoint B. Drag either endpoint afterward.':'Click near the lidar-aligned route. Amber stretches require Draw A–B. Drag A or B for manual adjustment.';}
$('autoBtn').onclick=()=>setMode('auto');$('drawBtn').onclick=()=>setMode('draw');$('sectionWidth').onchange=makeAutoSection;$('showBanks').onchange=()=>{if(state.section)drawSectionProfile();};$('connectBanks').onchange=()=>{if(state.section)drawSectionProfile();};$('fitSection').onchange=()=>{if(state.section)drawSectionProfile();};$('rotation').oninput=()=>{$('rotationValue').textContent=$('rotation').value+'°';makeAutoSection();};
$('clearSection').onclick=()=>{++state.sectionToken;state.section=null;state.sectionSamples=[];state.autoCenter=null;endpoints.forEach(m=>map.removeLayer(m));endpoints=[];sectionLine.setLatLngs([]);map.removeLayer(sectionPoint);$('sectionStatus').textContent='No section selected. Gaps will remain gaps.';$('sectionCoords').textContent='';$('exportSection').disabled=true;blankSection();};
$('methodsBtn').onclick=()=>{$('methodsModal').hidden=false;};$('closeMethods').onclick=()=>{$('methodsModal').hidden=true;};$('methodsModal').onclick=e=>{if(e.target===$('methodsModal'))$('methodsModal').hidden=true;};document.addEventListener('keydown',e=>{if(e.key==='Escape'){$('methodsModal').hidden=true;state.drawStart=null;if(drawMarker)map.removeLayer(drawMarker);$('sectionHelp').textContent=state.mode==='draw'?'Click endpoint A, then endpoint B.':'Click near the lidar-aligned route. Amber stretches require Draw A–B.';}});
function blankSection(){return Plotly.react('sectionPlot',[],{...commonLayout,margin:{l:50,r:8,t:8,b:40},xaxis:{title:'Distance from A (m)',range:[0,200],gridcolor:'#e8edef'},yaxis:{title:'Bed elevation (m)',range:[0,1],showticklabels:false,gridcolor:'#e8edef'},annotations:[{text:'Click the channel or draw A–B',xref:'paper',yref:'paper',x:.5,y:.5,showarrow:false,font:{size:11,color:'#647880'}}]},plotConfig);}
map.on('click',e=>handleMapClick(e.latlng));map.on('movestart',()=>{++state.rasterToken;canvas.style.display='none';});let moveTimer;map.on('moveend',()=>{clearTimeout(moveTimer);moveTimer=setTimeout(()=>{updateStyles();updateProfile();const v=visibleIndices();$('mapExtent').textContent=v.length?`River km ${rows[v[0]].km.toFixed(1)}–${(rows[v.at(-1)].km+rows[v.at(-1)].len/1000).toFixed(1)}`:'Outside the mapped mainstem';renderBed();},90);});map.on('mousemove',e=>{const q=toXY(e.latlng);$('cursorCoords').textContent=`${e.latlng.lat.toFixed(5)}, ${e.latlng.lng.toFixed(5)} · E ${q[0].toFixed(1)} N ${q[1].toFixed(1)} m`;});
(async()=>{map.fitBounds(allBounds,{padding:[25,25]});await updateProfile(true);await blankSection();$('profile').on('plotly_hover',e=>{if(e.points?.length)hoverInterval(e.points[0].customdata,true);});$('profile').on('plotly_unhover',()=>{setHighlight(state.selected);map.removeLayer(pointMarker);$('mapHover').textContent='';});$('profile').on('plotly_click',e=>{const i=e.points?.[0]?.customdata;if(i==null)return;selectInterval(i);map.setView(rows[i].center,Math.max(15,map.getZoom()));if(state.mode==='auto')handleMapClick(L.latLng(rows[i].center),i);});$('profile').on('plotly_relayout',e=>{if(state.plotUpdating)return;let lo=e['xaxis.range[0]']??e['xaxis.range']?.[0],hi=e['xaxis.range[1]']??e['xaxis.range']?.[1];if(e['xaxis.autorange']){map.fitBounds(allBounds,{padding:[25,25]});return;}if(lo==null||hi==null)return;const selected=rows.filter(r=>r.km+r.len/1000>=lo&&r.km<=hi);if(selected.length)map.fitBounds(L.latLngBounds(selected.flatMap(r=>r.ll.map(c=>[c[1],c[0]]))),{padding:[45,45],maxZoom:17});});$('sectionPlot').on('plotly_hover',e=>{const i=e.points?.[0]?.customdata,s=state.sectionSamples[i];if(s)sectionPoint.setLatLng([s.lat,s.lon]).addTo(map);});$('sectionPlot').on('plotly_unhover',()=>map.removeLayer(sectionPoint));requestAnimationFrame(()=>setTimeout(initRasters,10));})();
function adaptPlot(id){
 const el=$(id);if(!el._fullLayout)return Promise.resolve();const w=el.clientWidth,h=el.clientHeight,sz=Math.max(11,Math.min(14,Math.round(w/44))),section=id==='sectionPlot';
 return Plotly.relayout(el,{'font.size':sz,'margin.l':section?56:59,'margin.r':12,'margin.b':42,'xaxis.automargin':true,'yaxis.automargin':true,'xaxis.nticks':Math.max(3,Math.floor(w/90)),'yaxis.nticks':Math.max(3,Math.floor(h/60)),'xaxis.title.font.size':sz+1,'yaxis.title.font.size':sz+1,'xaxis.title.text':section?'Distance from A (m)':w<650?'River km (downstream)':'Distance downstream from upstream survey edge (km)'});
}
const workspace=document.querySelector('.workspace'),layoutKey='eel-viewer-layout-v2';
let paneSizes={side:390,map:.6,section:300,mobileMap:360};
try{const saved=JSON.parse(localStorage.getItem(layoutKey));if(saved)for(const k of Object.keys(paneSizes))if(Number.isFinite(saved[k]))paneSizes[k]=saved[k];}catch{}
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function applyPaneSizes(){
 const mobile=innerWidth<=760,available=workspace.clientHeight-9;
 paneSizes.side=clamp(paneSizes.side,280,Math.max(280,workspace.clientWidth-329));paneSizes.map=clamp(paneSizes.map,210/Math.max(431,available),1-220/Math.max(431,available));paneSizes.section=clamp(paneSizes.section,180,900);paneSizes.mobileMap=clamp(paneSizes.mobileMap,240,900);
 workspace.style.setProperty('--map-height',Math.max(210,paneSizes.map*available)+'px');workspace.style.setProperty('--profile-height',Math.max(220,(1-paneSizes.map)*available)+'px');workspace.style.setProperty('--side-width',paneSizes.side+'px');workspace.style.setProperty('--map-fr',paneSizes.map+'fr');workspace.style.setProperty('--profile-fr',(1-paneSizes.map)+'fr');workspace.style.setProperty('--section-height',paneSizes.section+'px');workspace.style.setProperty('--mobile-map-height',paneSizes.mobileMap+'px');
 for(const [id,v,min,max]of[['sideSplitter',paneSizes.side,280,Math.max(280,workspace.clientWidth-329)],['mapProfileSplitter',mobile?paneSizes.mobileMap:paneSizes.map*available,mobile?240:210,mobile?900:available-220],['sectionSplitter',paneSizes.section,180,900]]){for(const [key,value]of[['now',v],['min',min],['max',max]])$(id).setAttribute('aria-value'+key,Math.round(value));}
}
function savePaneSizes(){try{localStorage.setItem(layoutKey,JSON.stringify(paneSizes));}catch{}}
function bindSplitter(id,key,vertical=false){
 const el=$(id);let drag=null;
 function change(delta,start){if(key==='side')paneSizes.side=start-delta;else if(key==='map')innerWidth<=760?paneSizes.mobileMap=start+delta:paneSizes.map=(start+delta)/(workspace.clientHeight-9);else paneSizes.section=start+delta;applyPaneSizes();}
 const current=()=>key==='map'?(innerWidth<=760?paneSizes.mobileMap:document.querySelector('.map-panel').clientHeight):paneSizes[key];
 el.onpointerdown=e=>{if(e.button!==0)return;e.preventDefault();drag={p:vertical?e.clientX:e.clientY,size:current()};el.setPointerCapture(e.pointerId);el.classList.add('dragging');document.body.classList.add('resizing',vertical?'resizing-col':'resizing-row');};
 el.onpointermove=e=>{if(drag)change((vertical?e.clientX:e.clientY)-drag.p,drag.size);};
 el.onpointerup=el.onpointercancel=()=>{drag=null;el.classList.remove('dragging');document.body.classList.remove('resizing','resizing-col','resizing-row');savePaneSizes();};
 el.onkeydown=e=>{const delta=({ArrowLeft:-16,ArrowRight:16,ArrowUp:-16,ArrowDown:16})[e.key];if(delta!=null){e.preventDefault();change(delta,current());savePaneSizes();}};
 el.ondblclick=()=>{paneSizes[key]=({side:390,map:.6,section:300})[key];if(key==='map')paneSizes.mobileMap=360;applyPaneSizes();savePaneSizes();};
}
bindSplitter('sideSplitter','side',true);bindSplitter('mapProfileSplitter','map');bindSplitter('sectionSplitter','section');
$('resetLayout').onclick=()=>{paneSizes={side:390,map:.6,section:300,mobileMap:360};applyPaneSizes();savePaneSizes();};
new ResizeObserver(applyPaneSizes).observe(workspace);L.DomEvent.disableClickPropagation(document.querySelector('.map-legend'));L.DomEvent.disableScrollPropagation(document.querySelector('.map-legend'));applyPaneSizes();window.addEventListener('resize',applyPaneSizes);
let resizeTimer;const paneObserver=new ResizeObserver(()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(async()=>{map.invalidateSize({pan:false,debounceMoveend:true});for(const id of ['profile','sectionPlot'])if($(id)._fullLayout){await Plotly.Plots.resize(id);await adaptPlot(id);}renderBed();},100);});
for(const el of [document.querySelector('.map-panel'),$('profile'),$('sectionPlot')])paneObserver.observe(el);
// Expose numerical and map state for reproducible local checks.
window.EelViewer={map,state,rows,toXY,toLL,nearestRiver,sampleSection,handleMapClick,selectInterval,setSection,updateProfile,renderBed,visibleIndices};
