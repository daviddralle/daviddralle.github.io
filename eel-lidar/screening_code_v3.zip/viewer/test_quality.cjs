const fs=require('fs'),vm=require('vm'),assert=require('assert');const app=fs.readFileSync('app.js','utf8'),ctx={};vm.createContext(ctx);vm.runInContext(app.slice(app.indexOf('function bankBedLinks('),app.indexOf('async function drawSectionProfile(')),ctx);
const a={distance:0,z:null,ground:35,qc:0},b={distance:10,z:30,ground:null,qc:1};assert.equal(ctx.bankBedLinks([a,b]).length,1);
for(const qc of [2,3,5])assert.equal(ctx.bankBedLinks([a,{distance:5,z:null,ground:null,qc},b]).length,0);
assert.equal(ctx.bankBedLinks([{distance:0,z:30,ground:null,qc:1},{distance:10,z:29,ground:null,qc:1}]).length,0);
const {JSDOM}=(()=>{try{return require('jsdom')}catch{return{}}})();
const report={result:'PASS',bank_bed_joins_do_not_bridge_flagged_bed:true,internal_bed_gaps_remain_open:true};fs.writeFileSync('quality_display_verification.json',JSON.stringify(report,null,2));console.log(report);
