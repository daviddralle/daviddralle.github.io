from pathlib import Path
import json,hashlib,re,base64
import numpy as np,rasterio
from shapely.geometry import LineString,box
P=Path(__file__).parent;S=P.parent/'full_mainstem/qgis_full_mainstem';results=json.loads((P/'numerical_results.json').read_text());report={'sections':[],'map_extent_tests':0}
with rasterio.open(S/'eel_mainstem_bathy_v3_1m.tif') as bed,rasterio.open(S/'eel_mainstem_bathy_v3_1m_support.tif') as support:
 for case in results['cases']:
  samples=case['samples'];xy=[(s['x'],s['y']) for s in samples];expected=np.array([z[0] for z in bed.sample(xy)]);observed=np.array([s['z'] if s['z'] is not None else -9999 for s in samples]);flags=np.array([v[0] for v in support.sample(xy)]);gotflags=np.array([s['support'] for s in samples]);assert np.array_equal(expected,observed),(case['name'],np.max(abs(expected-observed)));assert np.array_equal(flags,gotflags),case['name'];report['sections'].append({'name':case['name'],'samples':len(samples),'valid':int((expected!=-9999).sum()),'exact_elevation_and_support_match':True})
with rasterio.open(S/'eel_mainstem_banks_v2_2m.tif') as ground,rasterio.open(S/'eel_mainstem_banks_v2_2m_support.tif') as support:
 for case in results['cases']:
  samples=case['samples'];xy=[(s['x'],s['y']) for s in samples]
  expected=np.array([z[0] for z in ground.sample(xy)]);observed=np.array([s['ground'] if s['ground'] is not None else -9999 for s in samples])
  flags=np.array([z[0] for z in support.sample(xy)]);observedflags=np.array([s['groundSupport'] for s in samples])
  mask=np.array([x['qc'] in [2,3,5] for x in samples]);expected[mask]=-9999;flags[mask]=0;assert np.array_equal(expected,observed),case['name'];assert np.array_equal(flags,observedflags),case['name']
  item=next(r for r in report['sections'] if r['name']==case['name']);item['ground_valid']=int((expected!=-9999).sum());item['exact_ground_elevation_and_support_match']=True
with rasterio.open(S/'eel_mainstem_bed_quality_v3_1m.tif') as quality,rasterio.open(S/'eel_mainstem_bathy_v2_1m.tif') as old:
 for case in results['cases']:
  samples=case['samples'];xy=[(s['x'],s['y']) for s in samples];q=[int(v[0]) for v in quality.sample(xy)];assert q==[s['qc'] for s in samples]
  original=np.array([v[0] for v in old.sample(xy)]);observed=np.array([s['original'] if s['original'] is not None else -9999 for s in samples]);assert np.array_equal(original==-9999,observed==-9999);valid=original!=-9999;assert np.max(abs(original[valid]-observed[valid]),initial=0)<.0051
report['quality_flags_and_original_comparison_verified']=True
data=json.loads((P/'data.json').read_text());lines=[LineString(r['ll']) for r in data['rows']]
for t in results['viewTests']:
 b=box(*t['bounds']);expected=[i for i,g in enumerate(lines) if g.intersects(b)];assert expected==t['indices'];report['map_extent_tests']+=1
html=(P/'eel_lidar_viewer.html').read_text()
for el,file in [('bathy-bytes','eel_mainstem_bathy_v3_1m.tif'),('support-bytes','eel_mainstem_bathy_v3_1m_support.tif'),('bank-bytes','eel_mainstem_banks_v2_2m.tif'),('bank-support-bytes','eel_mainstem_banks_v2_2m_support.tif'),('quality-bytes','eel_mainstem_bed_quality_v3_1m.tif'),('original-bytes','eel_original_v2_comparison_cm.tif')]:
 encoded=re.search(r'id="'+el+r'" type="application/octet-stream">([^<]+)</script>',html)[1];embedded=hashlib.sha256(base64.b64decode(encoded)).hexdigest();source=hashlib.sha256((S/file).read_bytes()).hexdigest();assert embedded==source;report[file+'_embedded_sha256']=source
report['total_cross_section_samples']=sum(x['samples'] for x in report['sections']);report['result']='PASS';(P/'numerical_verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
