"""Restore v2; exclude only the reviewed upper band in the km 152.4 pool.

This is a local manual review mask, not a shallow-water classifier. No bed
elevations are estimated. Original files are never modified.
"""
from pathlib import Path
import csv, json, shutil, sqlite3, hashlib
import numpy as np
import rasterio
from rasterio.features import geometry_mask, shapes
from rasterio.windows import from_bounds
from scipy.ndimage import distance_transform_edt
from shapely.geometry import Polygon, shape, mapping
from shapely.ops import unary_union, transform
from pyproj import Transformer

P = Path(__file__).resolve().parent
S = P.parent / 'qgis_full_mainstem'
# Hand-delineated interior of the elevated plateau in the raw-point audit.
# The legitimate shallow margins and upstream/downstream transition are outside.
outline = [(421674,4469595),(421686,4469595),(421707,4469612),
 (421729,4469640),(421747,4469675),(421747,4469687),
 (421738,4469700),(421746,4469715),(421728,4469727),
 (421713,4469738),(421704,4469733),(421691,4469716),
 (421683,4469695),(421675,4469660),(421670,4469645),
 (421678,4469630),(421672,4469610),(421674,4469595)]
polygon = Polygon(outline)
assert polygon.is_valid
bounds = (421600,4469580,421820,4469790)
with rasterio.open(S/'eel_mainstem_bathy_v2_1m.tif') as ds:
 window = from_bounds(*bounds, ds.transform)
 tf = ds.window_transform(window)
 original = ds.read(1, window=window)
inside = geometry_mask([mapping(polygon)], original.shape, tf, invert=True)
# 32.30 m is only a local boundary between the audited upper and lower bands.
# It must never be applied to another pool or to the whole river.
removed = inside & (original >= 32.30) & (original != -9999)
assert removed.sum() > 1000
edit_geometry = unary_union([shape(g) for g,v in shapes(removed.astype('uint8'), mask=removed, transform=tf) if v == 1])
to_ll = Transformer.from_crs(26910,4326,always_xy=True).transform
feature = {'type':'Feature','properties':{'id':'pool152_4_upper_band','reason':'Audited false upper band within a manually delineated deep-pool interior; no inferred bottom','local_elevation_cutoff_m':32.30,'removed_cells':int(removed.sum()),'source_datum':'GEOID12A','route_version':'lidar2014-v2'},'geometry':mapping(transform(to_ll,edit_geometry))}
(P/'pool_exclusion.geojson').write_text(json.dumps({'type':'FeatureCollection','features':[feature]},separators=(',',':')))
(P/'review_boundary_utm26910.json').write_text(json.dumps({'crs':'EPSG:26910','geometry':mapping(polygon),'grid_bounds':bounds},indent=2))
distance = distance_transform_edt(~removed)
files = [
 ('eel_mainstem_bathy_v2_1m.tif', removed),
 ('eel_mainstem_bathy_v2_1m_support.tif', removed),
 ('eel_bed_return_density_v2_1m.tif', removed),
 ('eel_mainstem_interval_ids_v2_1m.tif', removed),
 *[(f'eel_roughness_rms_radius{r}m_v2_1m.tif',distance<=r+1.5) for r in (1,2,5)],
 ('eel_roughness_neighbors_radius1m_v2_1m.tif',distance<=2.5)]
report = {'release':'v2p1-local-pool-edit','baseline':'v2','excluded_bed_cells':int(removed.sum()),'review_polygon_area_m2':polygon.area,'files':{},'no_global_water_surface_filter':True,'no_reconstructed_depths':True}
for name, mask in files:
 source = S/name
 target = S/name.replace('_v2_','_v2p1_')
 shutil.copy2(source,target)
 with rasterio.open(target,'r+',IGNORE_COG_LAYOUT_BREAK='YES') as dst:
  a = dst.read(1,window=window)
  changed = mask & (a != dst.nodata)
  a[mask] = dst.nodata
  dst.write(a,1,window=window)
  dst.update_tags(release='v2p1-local-pool-edit',method='Original v2 values preserved except reviewed km 152.4 upper-band cells; roughness excluded within its neighborhood radius + 1.5 m of removed cells. No global surface-distance filter.',edit_mask='pool_exclusion.geojson')
  # Rebuild existing overviews so map previews agree with edited full resolution.
  levels = dst.overviews(1)
  if levels:
   resampling = rasterio.enums.Resampling.nearest if dst.dtypes[0].startswith(('uint','int')) else rasterio.enums.Resampling.average
   dst.build_overviews(levels,resampling)
 report['files'][target.name]={'changed_cells':int(changed.sum()),'source':name}
 print(target.name, int(changed.sum()), flush=True)

# Recompute ONLY affected 100-m records, using the unchanged v2 spatial IDs.
# Read a generous local window containing each affected interval's full domain;
# exact agreement with its original counts/statistics verifies completeness.
with rasterio.open(S/'eel_mainstem_interval_ids_v2_1m.tif') as ds:
 ids = ds.read(1,window=window)
 affected = sorted(int(v) for v in np.unique(ids[distance<=6.5]) if v)
 intervals = json.loads((P.parent/'centerline_v2/intervals.json').read_text())
 coords = np.vstack([intervals[i-1]['xy'] for i in affected])
 aggregate_bounds = (np.floor(coords[:,0].min()-310),np.floor(coords[:,1].min()-310),np.ceil(coords[:,0].max()+310),np.ceil(coords[:,1].max()+310))
 aggregate_window = from_bounds(*aggregate_bounds,ds.transform)
 assignment = ds.read(1,window=aggregate_window)
def read(name):
 with rasterio.open(S/name) as ds:return ds.read(1,window=aggregate_window)
def stats(version, identifier):
 bed=read(f'eel_mainstem_bathy_{version}_1m.tif')
 support=read(f'eel_mainstem_bathy_{version}_1m_support.tif')
 mask=(assignment==identifier)&(support>0)
 z=bed[mask]; den=read(f'eel_bed_return_density_{version}_1m.tif')[mask]; den=den[den!=-9999]
 result={'supported_bed_area_m2':int(mask.sum()),'direct_sampled_cell_area_m2':int((support[mask]==1).sum()),'bed_mean_return_density':float(np.mean(den,dtype=np.float64)) if len(den) else None,'min_bed_elevation_m':float(z.min()) if len(z) else None,'max_bed_elevation_m':float(z.max()) if len(z) else None}
 for r in (1,2,5):
  v=read(f'eel_roughness_rms_radius{r}m_{version}_1m.tif')[mask];v=v[v!=-9999]
  result.update({f'rough_r{r}_ncells':len(v),f'rough_r{r}_median_m':float(np.median(v)) if len(v) else None,f'rough_r{r}_p90_m':float(np.quantile(v,.9)) if len(v) else None,f'rough_r{r}_fraction_of_supported_bed':len(v)/len(z) if len(z) else None})
 return result
with open(S/'roughness_predictors_100m_v2.csv') as f:
 reader=csv.DictReader(f);fields=reader.fieldnames;records=list(reader)
changes={}
for identifier in affected:
 old=records[identifier-1]
 assert int(old['interval_id'])==identifier
 check=stats('v2',identifier)
 for key,value in check.items():
  assert (not old[key] and value is None) or np.isclose(float(old[key]),value,rtol=1e-7,atol=1e-8),(identifier,key,old[key],value)
 updated=stats('v2p1',identifier);changes[identifier]=updated
 for key,value in updated.items():old[key]='' if value is None else str(value)
with open(S/'roughness_predictors_100m_v2p1.csv','w') as f:
 writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(records)
gpkg=S/'river_centerline_v2p1.gpkg';shutil.copy2(S/'river_centerline_v2.gpkg',gpkg)
with sqlite3.connect(gpkg) as db:
 # Attribute-only updates; GeoPackage triggers may require spatial functions.
 db.create_function('ST_IsEmpty',1,lambda _:0)
 db.create_function('ST_MinX',1,lambda _:0);db.create_function('ST_MaxX',1,lambda _:0)
 db.create_function('ST_MinY',1,lambda _:0);db.create_function('ST_MaxY',1,lambda _:0)
 for identifier,updated in changes.items():
  db.execute('UPDATE roughness_corrected_100m SET '+','.join(f'"{k}"=?' for k in updated)+' WHERE interval_id=?',list(updated.values())+[identifier])
report['affected_interval_ids']=affected
report['original_total_bed_cells']=9033332
report['retained_fraction_of_v2']=1-removed.sum()/9033332
report['roughness_policy']='Values are unchanged outside a radius-specific exclusion halo (radius + 1.5 m). Halo prevents neighborhoods containing flagged returns from remaining in summaries; no whole-river recalculation.'
(P/'edit_report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
