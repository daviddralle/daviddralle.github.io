from pathlib import Path
P=Path(__file__).resolve().parents[2]/'viewer'
b=P/'before_quality_v3'
s=(b/'build_viewer.py').read_text().replace('river_centerline_v2.gpkg','river_centerline_v2p1.gpkg').replace('eel_mainstem_bathy_v2_','eel_mainstem_bathy_v2p1_')
s=s.replace("data=json.dumps({'meta':meta,'rows':rows,'reference':oldll}","edit_dir=P.parent/'full_mainstem/pool_edits'\nmeta['local_pool_edit']=json.loads((edit_dir/'edit_report.json').read_text())\nimport rasterio\nfrom rasterio.windows import from_bounds\nwith rasterio.open(S/'eel_mainstem_bathy_v2_1m.tif') as old_ds, rasterio.open(S/'eel_mainstem_bathy_v2p1_1m.tif') as new_ds:\n bounds=[421600,4469580,421820,4469790]; w=from_bounds(*bounds,old_ds.transform); old_z=old_ds.read(1,window=w); new_z=new_ds.read(1,window=w); mask=(old_z!=-9999)&(new_z==-9999)\nruns={}\nfor r in range(mask.shape[0]):\n cols=np.flatnonzero(mask[r]); breaks=np.flatnonzero(np.diff(cols)>1)+1\n if len(cols):runs[str(r)]=[[int(a[0]),int(a[-1])] for a in np.split(cols,breaks)]\npool_edit={'bounds':bounds,'runs':runs,'geojson':json.loads((edit_dir/'pool_exclusion.geojson').read_text())}\ndata=json.dumps({'meta':meta,'rows':rows,'reference':oldll,'poolEdit':pool_edit}")
(P/'build_viewer.py').write_text(s)
s=(b/'template.html').read_text()
s=s.replace('id="referenceToggle"','id="referenceToggle"')
needle='<label>Opacity'
# Insert independent overlay toggle next to existing contour control.
s=s.replace('<label><input type="checkbox" id="contourToggle" checked>', '<label><input type="checkbox" id="poolEditToggle" checked> Reviewed pool exclusion</label><label><input type="checkbox" id="contourToggle" checked>')
assert 'poolEditToggle' in s
s=s.replace('<h3>Roughness</h3>', '<h3>Local pool correction</h3><p>The river-wide screening was withdrawn because it removed legitimate shallow returns. The original v2 data are restored, except for 5,712 m² of the reviewed false upper band in the deep pool near km 152.4. The dashed orange outline marks the excluded cells. A hand-delineated pool-interior boundary and a local 32.30 m elevation cutoff identify this band; that cutoff is never applied elsewhere. Lower elevations in the pool remain unchanged. Missing bottom elevations stay NoData. This is a conservative manual exclusion, not a complete correction of all pools.</p><p>Roughness values whose neighborhoods could contain removed returns are omitted within each radius plus a 1.5 m margin. All other original roughness values are retained. Only the affected 100 m summaries are updated. <a href="https://daviddralle.github.io/eel-lidar/pool_exclusion.geojson">Exclusion mask</a> · <a href="https://daviddralle.github.io/eel-lidar/eel_mainstem_bathy_v2p1_1m.tif">Bed GeoTIFF</a> · <a href="https://daviddralle.github.io/eel-lidar/edit_report.json">Edit counts</a>.</p><h3>Roughness</h3>')
s=s.replace('roughness_predictors_100m_v2.csv','roughness_predictors_100m_v2p1.csv').replace('river_centerline_v2.gpkg','river_centerline_v2p1.gpkg')
s=s.replace('No section selected. Gaps will remain gaps.','No section selected. Gaps will remain gaps.')
s=s.replace('<details class="section"><summary>Reading the data</summary>', '<details class="section"><summary>Reading the data</summary><p class="instruction">Dashed orange outlines mark the local exclusion in the reviewed deep pool at km 152.4. Shallow returns elsewhere are retained.</p>')
(P/'template.html').write_text(s)
s=(b/'app.js').read_text()
s=s.replace("const allBounds=L.latLngBounds", "const poolEditLayer=L.geoJSON(DATA.poolEdit.geojson,{renderer:L.svg(),style:{color:'#b65c22',weight:1.5,dashArray:'4 4',fill:false},interactive:false});\n$('poolEditToggle').onchange=()=>{$('poolEditToggle').checked?poolEditLayer.addTo(map):map.removeLayer(poolEditLayer);};\nconst allBounds=L.latLngBounds")
s=s.replace('async function sampleSection(a,b){', "function poolExcluded(p){const [left,bottom,right,top]=DATA.poolEdit.bounds;if(p[0]<left||p[0]>=right||p[1]<=bottom||p[1]>top)return false;const col=Math.floor(p[0]-left),row=Math.floor(top-p[1]);return (DATA.poolEdit.runs[row]||[]).some(([a,b])=>col>=a&&col<=b);}\nasync function sampleSection(a,b){")
s=s.replace('ground:g[i],groundSupport:g[i]==null?0:gs[i]', 'ground:poolExcluded(p)?null:g[i],groundSupport:poolExcluded(p)||g[i]==null?0:gs[i],poolExcluded:poolExcluded(p)')
s=s.replace('if((a.z!=null)!==(b.z!=null)&&b.distance-a.distance<=maxGap)', 'if((a.z!=null)!==(b.z!=null)&&b.distance-a.distance<=maxGap&&!samples.some(s=>s.distance>=a.distance&&s.distance<=b.distance&&s.poolExcluded))')
s=s.replace("await adaptPlot('sectionPlot');", "if(samples.some(s=>s.poolExcluded))$('sectionStatus').textContent+=' Reviewed false upper-band cells are excluded here; bottom depth is unknown.';await adaptPlot('sectionPlot');")
s=s.replace("'ground_support_1_sampled_2_interpolated_0_nodata'],state.sectionSamples", "'ground_support_1_sampled_2_interpolated_0_nodata','reviewed_pool_exclusion'],state.sectionSamples")
s=s.replace('s.ground,s.groundSupport]));', 's.ground,s.groundSupport,s.poolExcluded?1:0]));')
s=s.replace('requestAnimationFrame(()=>setTimeout(initRasters,10));','poolEditLayer.addTo(map);requestAnimationFrame(()=>setTimeout(initRasters,10));')
(P/'app.js').write_text(s)
p=P/'resize_panels.css';p.write_text(p.read_text().replace(':has(#qualityLegend[hidden])',''))
intro='''Local pool edit v2p1 — October 1, 2026

The broad v3 water-surface screening has been withdrawn. It removed legitimate
shallow bed. The original v2 bed and roughness are restored everywhere except
a manually reviewed upper-band patch in the scoured pool near river km 152.4.

The exact 1 m exclusion footprint is pool_exclusion.geojson (WGS84). Within a
hand-delineated interior boundary, only original bed elevations >=32.30 m are
excluded: 5,712 cells, 0.0632% of the original 9,033,332 supported bed cells.
This absolute cutoff belongs ONLY to this audited pool. It is not a depth
threshold and is never applied to shallow water elsewhere. Lower elevations
within the boundary are preserved. Other false returns may remain, including
mixed cells at the edge; this is a conservative, localized correction.

Roughness is omitted where neighborhoods could include removed returns: each
radius plus 1.5 m from excluded cell centers. Original numerical roughness
values elsewhere remain unchanged. Only affected 100 m summaries are updated.
No bottom elevation is filled or inferred. Banks are unchanged and are not used
to fill the reviewed exclusion in sections. Dashed bank joins cannot cross it.
The map can toggle the orange exclusion outline; that does not restore the
excluded elevations. Original v2 rasters remain available locally for comparison.

Current bed: eel_mainstem_bathy_v2p1_1m.tif and matching _support.tif.
Current summaries: roughness_predictors_100m_v2p1.csv, river_centerline_v2p1.gpkg.
Current QGIS project: eel_mainstem_lidar_v2p1.qgz.
The route, banks, UI controls, colors, hillshades and contours remain at v2.
The earlier screened v3 imagery pilot is also withdrawn as the active pilot;
the original imagery/depth_pilot is preserved and remains experimental.

The sections below document the underlying v2 processing before this one-pool
exclusion. See edit_report.json and preservation_verification.json for changes.

'''
(P/'README.txt').write_text(intro+(b/'README.txt').read_text())
archive=P.parent/'full_mainstem/quality_v3/WITHDRAWN.txt';archive.write_text('WITHDRAWN: broad screening removed legitimate shallow bed. Do not use as the active bed/roughness release. Original v2 restored with local pool edit v2p1. Files retained only for reproducibility of the rejected experiment.\n')
(P.parent/'imagery/depth_pilot_v3/WITHDRAWN.txt').write_text('WITHDRAWN from active use with the broad v3 screen. Use original imagery/depth_pilot for the unvalidated optical trial. No evidence here validates deep-pool prediction.\n')
print('Restored v2 viewer and added local-pool provenance and gap protection.')
