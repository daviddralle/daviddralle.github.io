from pathlib import Path
import json
import numpy as np,rasterio
P=Path(__file__).resolve().parent;S=P.parent/'qgis_full_mainstem';V=P.parents[1]/'viewer'
result=json.loads((V/'numerical_results.json').read_text());n=0
with rasterio.open(S/'eel_mainstem_bathy_v2_1m.tif') as old,rasterio.open(S/'eel_mainstem_bathy_v2p1_1m.tif') as new:
 for case in result['cases']:
  samples=case['samples'];xy=[(s['x'],s['y']) for s in samples]
  a=np.array([v[0] for v in old.sample(xy)]);b=np.array([v[0] for v in new.sample(xy)]);expected=(a!=-9999)&(b==-9999)
  assert np.array_equal(expected,[s['poolExcluded'] for s in samples]),case['name']
  n+=int(expected.sum())
assert n>50
(P/'section_exclusion_verification.json').write_text(json.dumps({'result':'PASS','sections':len(result['cases']),'excluded_positions':n,'flags_match_actual_raster_difference':True},indent=2));print('PASS',n,'excluded section positions')
