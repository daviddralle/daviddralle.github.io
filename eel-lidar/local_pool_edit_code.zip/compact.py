from pathlib import Path
from osgeo import gdal
gdal.UseExceptions()
S=Path(__file__).resolve().parent.parent/'qgis_full_mainstem'
for name in ['eel_mainstem_bathy_v2p1_1m.tif','eel_mainstem_bathy_v2p1_1m_support.tif']:
 p=S/name;q=S/(p.stem+'_compact.tif')
 ds=gdal.Translate(str(q),str(p),format='COG',creationOptions=['COMPRESS=DEFLATE','LEVEL=9','PREDICTOR=YES','SPARSE_OK=YES','NUM_THREADS=2','OVERVIEWS=FORCE_USE_EXISTING'])
 ds=None
 q.replace(p);print(name,p.stat().st_size,flush=True)
