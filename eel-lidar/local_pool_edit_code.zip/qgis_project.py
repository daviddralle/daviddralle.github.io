from pathlib import Path
import os,json
for key in ['GDAL_DRIVER_PATH','GDAL_DATA','PDAL_DRIVER_PATH','PROJ_LIB','PROJ_DATA']:os.environ.pop(key,None)
from qgis.core import *
from qgis.PyQt.QtGui import QColor
P=Path(__file__).resolve().parent;S=P.parent/'qgis_full_mainstem'
app=QgsApplication([],False);app.initQgis();pr=QgsProject.instance();assert pr.read(str(S/'eel_mainstem_lidar_v2.qgz'));pr.setFilePathStorage(Qgis.FilePathType.Relative);pr.setTitle('Eel River — v2 restored; local exclusion in reviewed km 152.4 pool')
for layer in list(pr.mapLayers().values()):
 src=layer.source();file=Path(src.split('|')[0]);replacement=S/file.name.replace('_v2','_v2p1')
 if replacement!=file and replacement.exists():
  renderer=layer.renderer().clone();layer.setDataSource(src.replace(file.name,replacement.name),layer.name()+' (local pool edit)',layer.providerType());layer.setRenderer(renderer)
  if 'bathy_v2p1_1m.tif'==replacement.name.removeprefix('eel_mainstem_'):layer.elevationProperties().setEnabled(True);layer.elevationProperties().setBandNumber(1)
mask=QgsVectorLayer(str(P/'pool_exclusion.geojson'),'Reviewed pool exclusion (km 152.4)','ogr');assert mask.isValid();symbol=QgsFillSymbol.createSimple({'color':'0,0,0,0','outline_color':'182,92,34','outline_style':'dash','outline_width':'0.5'});mask.renderer().setSymbol(symbol);pr.addMapLayer(mask)
original=QgsRasterLayer(str(S/'eel_mainstem_bathy_v2_1m.tif'),'Original v2 bed — unchanged comparison');assert original.isValid();pr.addMapLayer(original);pr.layerTreeRoot().findLayer(original.id()).setItemVisibilityChecked(False)
bookmark=QgsBookmark();bookmark.setName('Reviewed pool exclusion near km 152.4');extent=QgsReferencedRectangle(QgsRectangle(421530,4469510,421900,4469850),pr.crs());bookmark.setExtent(extent);pr.bookmarkManager().addBookmark(bookmark);pr.viewSettings().setDefaultViewExtent(extent)
out=S/'eel_mainstem_lidar_v2p1.qgz';assert pr.write(str(out));pr.clear();assert pr.read(str(out));invalid=[l.name() for l in pr.mapLayers().values() if not l.isValid()];assert not invalid
(P/'qgis_verification.json').write_text(json.dumps({'result':'PASS','valid_layers':len(pr.mapLayers()),'relative_paths':True,'project':str(out)},indent=2));print('PASS',len(pr.mapLayers()),'valid layers');pr.clear()
