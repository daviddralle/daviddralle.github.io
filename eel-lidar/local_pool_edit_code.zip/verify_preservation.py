from pathlib import Path
import json,csv,hashlib,sqlite3
import numpy as np,rasterio,tifffile
from rasterio.windows import Window,from_bounds
from rasterio.features import geometry_mask
from shapely.geometry import shape
from scipy.ndimage import distance_transform_edt
P=Path(__file__).resolve().parent;S=P.parent/'qgis_full_mainstem'
report=json.loads((P/'edit_report.json').read_text());review=json.loads((P/'review_boundary_utm26910.json').read_text());bounds=review['grid_bounds']
with rasterio.open(S/'eel_mainstem_bathy_v2_1m.tif') as ds:
 w=from_bounds(*bounds,ds.transform);z=ds.read(1,window=w);inside=geometry_mask([review['geometry']],z.shape,ds.window_transform(w),invert=True);removed=inside&(z>=32.30)&(z!=-9999)
distance=distance_transform_edt(~removed)
results={}
for name,info in report['files'].items():
 old=S/info['source'];new=S/name
 # Inspect only allocated TIFF blocks, including blocks allocated in either file.
 with tifffile.TiffFile(old) as a,tifffile.TiffFile(new) as b:
  p=a.pages[0];q=b.pages[0];assert p.shape==q.shape
  bw=bh=min(p.tilewidth,q.tilewidth,p.tilelength,q.tilelength);ncols=(p.imagewidth+bw-1)//bw;offsets=set()
  for page in (p,q):
   source_cols=(page.imagewidth+page.tilewidth-1)//page.tilewidth
   for k in np.flatnonzero(np.asarray(page.dataoffsets)>0):
    r=int(k//source_cols*page.tilelength);c=int(k%source_cols*page.tilewidth)
    for yy in range(r,min(r+page.tilelength,page.imagelength),bh):
     for xx in range(c,min(c+page.tilewidth,page.imagewidth),bw):offsets.add(yy//bh*ncols+xx//bw)
  offsets=sorted(offsets)
 with rasterio.open(old) as a,rasterio.open(new) as b:
  assert a.crs==b.crs and a.transform==b.transform and a.nodata==b.nodata
  n=0;valid=0;outside=0
  for k in offsets:
   r=int(k//ncols*bh);c=int(k%ncols*bw);h=min(bh,a.height-r);width=min(bw,a.width-c);win=Window(c,r,width,h)
   x=a.read(1,window=win);y=b.read(1,window=win);valid+=int((x!=a.nodata).sum());rr,cc=np.nonzero(x!=y);n+=len(rr)
   if len(rr):
    yy=rr+r-int(w.row_off);xx=cc+c-int(w.col_off);assert np.all((yy>=0)&(yy<removed.shape[0])&(xx>=0)&(xx<removed.shape[1]))
    radius=next((v for v in (1,2,5) if f'radius{v}m' in name),None)
    allowed=distance<=radius+1.5 if radius else removed
    assert np.all(allowed[yy,xx]),name
    assert np.all(y[rr,cc]==b.nodata),name
  assert n==info['changed_cells'],(name,n,info)
  results[name]={'changed_cells':n,'original_valid_cells':valid,'all_other_pixels_exactly_equal':True,'changed_cells_all_nodata':True,'allocated_blocks_checked':len(offsets),'sha256':hashlib.sha256(new.read_bytes()).hexdigest()}
  if name=='eel_mainstem_bathy_v2p1_1m.tif':assert valid==report['original_total_bed_cells']
  print(name,n,'PASS',flush=True)
with open(S/'roughness_predictors_100m_v2.csv') as f:old=list(csv.DictReader(f))
with open(S/'roughness_predictors_100m_v2p1.csv') as f:new=list(csv.DictReader(f))
changed=[int(a['interval_id']) for a,b in zip(old,new) if a!=b]
assert changed==report['affected_interval_ids']
with sqlite3.connect(S/'river_centerline_v2.gpkg') as a,sqlite3.connect(S/'river_centerline_v2p1.gpkg') as b:
 for table in ['roughness_corrected_100m','original_NHD_guide','cross_sections_corrected_250m']:
  cols=[r[1] for r in a.execute(f'pragma table_info({table})')];geom=next(c for c in cols if c in ['geom','geometry'])
  assert a.execute(f'SELECT {geom} FROM {table} ORDER BY fid').fetchall()==b.execute(f'SELECT {geom} FROM {table} ORDER BY fid').fetchall()
 assert a.execute('SELECT * FROM rtree_roughness_corrected_100m_geom ORDER BY id').fetchall()==b.execute('SELECT * FROM rtree_roughness_corrected_100m_geom ORDER BY id').fetchall()
result={'result':'PASS','files':results,'unchanged_interval_records':len(old)-len(changed),'changed_interval_ids':changed,'all_route_and_transect_geometries_unchanged':True,'retained_bed_fraction':report['retained_fraction_of_v2']}
(P/'preservation_verification.json').write_text(json.dumps(result,indent=2));print('ALL PASS')
