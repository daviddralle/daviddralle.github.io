Well record: drift and datum corrections
========================================

All measurements, calibration evidence and field notes in this project are synthetic. Edits have already been applied. Use the interval buttons to inspect them, review Edit history, or use Undo and Redo. Opening an example creates a separate editable project.

OPEN THE EXAMPLE
Open Adjuster.html and choose this example on the project screen. It is generated locally, including its completed edit history. Alternatively use Restore project backup to load well.adjuster.gz. Opening the example again creates a fresh project.

FILES
The original input CSVs and known simulated values are included here. corrected-example.csv is the first station’s completed result; the second station has a separate corrected CSV. The reference and manual observations are also synthetic.

1. Drift and persistent bias
2025-01-05T14:00:00.000Z through 2025-01-21T05:00:00.000Z
Compare original and corrected depth over the drift interval. The first two history entries remove a ramp and its remaining constant bias. Manual readings provide the synthetic calibration evidence.

2. Sensor repositioning
2025-01-20T14:00:00.000Z through 2025-01-26T00:00:00.000Z
The +0.24 m change begins at Jan 21 00:00 UTC. A negative offset corrects depth to water; depth increases downward on the plot. Export also contains elevation = 102.5 m − corrected depth.

3. Spike and short outage
2025-01-11T10:00:00.000Z through 2025-01-12T06:00:00.000Z
The spike was marked missing, interpolated and reviewed. The separate six-hour outage was interpolated but remains questionable. Quality flags do not change measured values.

4. Interpolated outage
2025-01-30T14:00:00.000Z through 2025-01-31T15:00:00.000Z
Raw values remain blank at six timestamps. The interpolation creates corrected values only at those existing timestamps. Compare with Known simulated values to see the approximation error.

5. Absent timestamps
2025-02-06T11:00:00.000Z through 2025-02-08T03:00:00.000Z
Twelve hourly timestamps are absent on Feb 7. They stay absent after correction and export. No automatic resampling or timestamp insertion occurs.

6. W03: independent station corrections
2025-01-08T12:00:00.000Z through 2025-01-19T08:00:00.000Z
Switch between the two editable stations at the same time window. This station has a temporary +0.15 m bias, its own field measurements and a different hydrologic response. Compare with its known simulated values. Corrections and quality status belong to the selected station; Undo and Redo follow project-wide history.

7. W03: retain a missing observation
2025-01-27T16:00:00.000Z through 2025-01-28T12:00:00.000Z
The isolated spike is marked missing and bad. It remains blank in the corrected CSV. Try Restore original on this single record, preview and apply with a reason, then Undo to recover the reviewed result. Original measurements remain available throughout.

GENERATION
Deterministic analytic signals with inserted measurement faults; no downloaded observations or randomness. See lib/examples.ts in the application source for equations. Missing records, missing values, rounded logger precision and simulated relationships are intentional. These examples demonstrate software behavior, not field calibration validity.
