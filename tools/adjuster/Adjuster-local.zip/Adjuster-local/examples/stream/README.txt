Stream stage: reconstruction and discharge
==========================================

All measurements, calibration evidence and field notes in this project are synthetic. Edits have already been applied. Use the interval buttons to inspect them, review Edit history, or use Undo and Redo. Opening an example creates a separate editable project.

OPEN THE EXAMPLE
Open Adjuster.html and choose this example on the project screen. It is generated locally, including its completed edit history. Alternatively use Restore project backup to load stream.adjuster.gz. Opening the example again creates a fresh project.

FILES
The original input CSVs and known simulated values are included here. corrected-example.csv is the completed result. The reference and manual observations are also synthetic.

1. Calibration and datum shift
2024-11-06T20:00:00.000Z through 2024-11-07T12:15:00.000Z
The scale correction is applied first, followed by a −0.06 m offset after the datum shift. View Edit history for parameters and reasons; Undo operates on the entire project.

2. Flatline reconstruction
2024-11-04T20:30:00.000Z through 2024-11-05T06:30:00.000Z
Twenty flatlined readings were marked missing then reconstructed from the raw reference. Toggle the reference curve and compare original, corrected and Known simulated values.

3. Quality review
2024-11-06T11:15:00.000Z through 2024-11-07T04:45:00.000Z
The largest storm peak remains questionable. Flags are independent of correction methods, and those readings are excluded from the example discharge export.

4. Stage to discharge
2024-11-02T13:30:00.000Z through 2024-11-04T03:00:00.000Z
Export is prefilled with the synthetic rating Q = 4.2 × (stage − 0.20)^1.6, valid for stage 0.25–0.85 m during this record. Only good, in-range readings receive discharge; other rows explain why discharge is blank. This is not a field rating.

GENERATION
Deterministic analytic signals with inserted measurement faults; no downloaded observations or randomness. See lib/examples.ts in the application source for equations. Missing records, missing values, rounded logger precision and simulated relationships are intentional. These examples demonstrate software behavior, not field calibration validity.
